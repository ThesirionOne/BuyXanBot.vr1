import axios from 'axios';
import { handleTelegramCommand } from './commands.js';
import { getUserState, clearUserState, USER_STATES } from './keyboards.js';

// Build the API URL safely, handling the colon in the token
const buildTelegramApiUrl = () => {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  if (!token) {
    console.error('❌ No Telegram bot token found');
    return null;
  }
  return `https://api.telegram.org/bot${token}`;
};

let isPolling = false;

export async function sendTelegramMessage(chatId, text, parseMode = "HTML", replyMarkup = null) {
  console.log('📤 sendTelegramMessage called with:');
  console.log('📤 - chatId:', chatId);
  console.log('📤 - text length:', text.length);
  console.log('📤 - parseMode:', parseMode);
  console.log('📤 - replyMarkup provided:', !!replyMarkup);
  
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send message - invalid bot token');
      return null;
    }
    
    const payload = {
      chat_id: chatId,
      text,
      parse_mode: parseMode
    };
    
    if (replyMarkup) {
      payload.reply_markup = replyMarkup;
      console.log('📤 Reply markup added to payload:', JSON.stringify(replyMarkup, null, 2));
    }
    
    console.log('📤 Full payload:', JSON.stringify(payload, null, 2));
    
    const response = await axios.post(`${TELEGRAM_API_URL}/sendMessage`, payload);
    
    console.log(`📤 API Response status:`, response.status);
    console.log(`📤 API Response data:`, JSON.stringify(response.data, null, 2));
    
    if (!response.data.ok) {
      console.error('❌ Telegram API error:', response.data);
      return response.data;
    }
    
    return response.data;
  } catch (error) {
    console.error(`Error sending message to ${chatId}:`, error.message);
    if (error.response) {
      console.error('Telegram API error response:', error.response.data);
    }
    return null;
  }
}

export async function sendTelegramRequest(method, params) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send request - invalid bot token');
      return null;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/${method}`, params);
    return response.data;
  } catch (error) {
    console.error(`Error sending ${method} request:`, error.message);
    return null;
  }
}

export async function sendTelegramAnimation(chatId, animationUrl) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send animation - invalid bot token');
      return null;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/sendAnimation`, {
      chat_id: chatId,
      animation: animationUrl
    });
    
    console.log(`Animation sent to ${chatId}: ${response.data.ok ? 'success' : 'failed'}`);
    return response.data;
  } catch (error) {
    console.error(`Error sending animation to ${chatId}:`, error.message);
    return null;
  }
}

export async function sendTelegramAnimationFromFileId(chatId, fileId) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send animation - invalid bot token');
      return null;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/sendAnimation`, {
      chat_id: chatId,
      animation: fileId
    });
    
    console.log(`Animation (file_id) sent to ${chatId}: ${response.data.ok ? 'success' : 'failed'}`);
    return response.data;
  } catch (error) {
    console.error(`Error sending animation (file_id) to ${chatId}:`, error.message);
    return null;
  }
}

export async function sendTelegramMessageWithGif(chatId, text, gifUrl, parseMode = "HTML", replyMarkup = null) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send message with GIF - invalid bot token');
      return null;
    }
    
    const payload = {
      chat_id: chatId,
      animation: gifUrl,
      caption: text,
      parse_mode: parseMode
    };
    
    if (replyMarkup) {
      payload.reply_markup = replyMarkup;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/sendAnimation`, payload);
    
    console.log(`Message with GIF sent to ${chatId}: ${response.data.ok ? 'success' : 'failed'}`);
    return response.data;
  } catch (error) {
    console.error(`Error sending message with GIF to ${chatId}:`, error.message);
    return null;
  }
}

export async function sendTelegramMessageWithGifFileId(chatId, text, fileId, parseMode = "HTML", replyMarkup = null) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot send message with GIF - invalid bot token');
      return null;
    }
    
    const payload = {
      chat_id: chatId,
      animation: fileId,
      caption: text,
      parse_mode: parseMode
    };
    
    if (replyMarkup) {
      payload.reply_markup = replyMarkup;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/sendAnimation`, payload);
    
    console.log(`Message with GIF (file_id) sent to ${chatId}: ${response.data.ok ? 'success' : 'failed'}`);
    return response.data;
  } catch (error) {
    console.error(`Error sending message with GIF (file_id) to ${chatId}:`, error.message);
    return null;
  }
}
export async function getTelegramUpdates(offset = 0) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot get updates - invalid bot token');
      return null;
    }
    
    // Only log every 20th check to reduce console spam
    if (offset % 20 === 0) {
      console.log(`🔍 Checking for updates with offset: ${offset}`);
    }
    
    const response = await axios.get(`${TELEGRAM_API_URL}/getUpdates`, {
      params: {
        offset,
        timeout: 30,
        limit: 100
      }
    });
    
    // Only log API response when there are actual updates
    if (response.data.result && response.data.result.length > 0) {
      console.log(`📡 Telegram API response: ${response.data.result.length} updates`);
    }
    
    return response.data;
  } catch (error) {
    console.error('Error getting updates:', error.message);
    return null;
  }
}

export async function startPolling() {
  if (isPolling) {
    console.log('⚠️  Polling already started');
    return;
  }
  
  isPolling = true;
  let offset = 0;
  
  console.log('🔄 Starting Telegram polling (optimized)...');
  
  while (isPolling) {
    try {
      const result = await getTelegramUpdates(offset);
      
      if (result && result.ok && result.result.length > 0) {
        console.log(`📨 Received ${result.result.length} new message(s)`);
        for (const update of result.result) {
          console.log(`🔄 Processing update ${update.update_id}`);
          console.log(`🔄 🔥 🔥 🔥 POLLING - About to call handleTelegramWebhook`);
          console.log(`🔄 🔥 Update data:`, JSON.stringify(update, null, 2));
          await handleTelegramWebhook(update);
          console.log(`🔄 🔥 🔥 🔥 POLLING - handleTelegramWebhook completed`);
          offset = update.update_id + 1;
        }
        console.log(`✅ All updates processed, new offset: ${offset}`);
      } else if (result && result.ok) {
        // Only log every 10th check to reduce spam
        if (offset % 10 === 0) {
          console.log(`👂 Listening for messages... (offset: ${offset})`);
        }
      } else if (result) {
        console.error('❌ Telegram API error:', result);
      } else {
        console.error('❌ No response from Telegram API');
      }
      
      // Optimized delay - shorter for active conversations
      const delay = result?.result?.length > 0 ? 1000 : 3000;
      await new Promise(resolve => setTimeout(resolve, delay));
      
    } catch (error) {
      console.error('❌ Polling error:', error.message);
      console.error('❌ Polling error stack:', error.stack);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}

export function stopPolling() {
  isPolling = false;
  console.log('🛑 Telegram polling stopped');
}

export async function setTelegramWebhook(webhookUrl) {
  try {
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Cannot set webhook - invalid bot token');
      return null;
    }
    
    const response = await axios.post(`${TELEGRAM_API_URL}/setWebhook`, {
      url: webhookUrl
    });
    
    console.log('Webhook set:', response.data);
    return response.data;
  } catch (error) {
    console.error('Error setting webhook:', error.message);
    return null;
  }
}

export async function handleTelegramWebhook(update) {
  try {
    console.log('📨 🔥 🔥 🔥 WEBHOOK HANDLER ENTRY - Processing Telegram update');
    console.log('📨 🔥 Update type:', typeof update);
    console.log('📨 🔥 Update keys:', Object.keys(update));
    // console.log('📨 🔥 Full update object:', JSON.stringify(update, null, 2)); // Too verbose
    
    // Declare variables at function scope to avoid ReferenceError
    let message, text, chatId;
    
    if (update.message) {
      message = update.message;
      text = message.text;
      chatId = message.chat?.id;
      
      console.log(`💬 🔥 🔥 🔥 MESSAGE DETECTED from chat ${chatId}: "${text || '[no text]'}"`);
      
      // Detectar si es un grupo y configurar automáticamente
      await handleChatTypeDetection(message.chat);
      
      // TEMPORARY DEBUG: Let's see what's actually happening
      console.log('🔍 🔥 🔥 🔥 DEBUGGING: About to check user state and command logic');
      
      // Check if user is in a state waiting for input
      const userState = getUserState(chatId);
      console.log('🔍 🔥 🔥 🔥 USER STATE:', userState);
      
      if (userState.state !== USER_STATES.IDLE && text && !text.startsWith('/')) {
        console.log(`🔄 🔥 🔥 🔥 USER IN STATE: ${userState.state}, handling input`);
        await handleUserInput(chatId, text, userState);
      } else if (text && text.startsWith('/')) {
        console.log(`🤖 🔥 🔥 🔥 COMMAND DETECTED: ${text} from chat ${chatId}`);
        console.log(`🔍 🔥 🔥 🔥 ABOUT TO IMPORT AND CALL handleTelegramCommand...`);
        try {
          console.log(`🔍 🔥 🔥 🔥 IMPORTING commands.js...`);
          const commandsModule = await import('./commands.js');
          console.log(`🔍 🔥 🔥 🔥 COMMANDS MODULE IMPORTED:`, Object.keys(commandsModule));
          console.log(`🔍 🔥 🔥 🔥 CALLING handleTelegramCommand...`);
          await commandsModule.handleTelegramCommand(chatId, text);
          console.log(`✅ 🔥 🔥 🔥 COMMAND PROCESSED SUCCESSFULLY`);
        } catch (error) {
          console.error(`❌ 🔥 🔥 🔥 ERROR IN handleTelegramCommand:`, error);
          console.error(`❌ 🔥 🔥 🔥 ERROR STACK:`, error.stack);
          throw error;
        }
      } else if (message.animation && userState.state === 'setting_gif_waiting_telegram') {
        console.log(`🎬 🔥 🔥 🔥 GIF RECEIVED from chat ${chatId}`);
        await handleGifSelection(chatId, message.animation);
      } else {
        console.log(`💬 🔥 🔥 🔥 NON-COMMAND MESSAGE from ${chatId}`);
      }
    } else if (update.callback_query) {
      console.log(`🔘 🔥 🔥 🔥 CALLBACK QUERY from chat ${update.callback_query.message.chat.id}`);
      const { handleCallbackQuery } = await import('./callback-handlers.js');
      await handleCallbackQuery(update.callback_query);
    } else {
      console.log('📨 🔥 🔥 🔥 UPDATE RECEIVED (no message):', Object.keys(update).join(', '));
    }
    
    console.log('📨 🔥 🔥 🔥 WEBHOOK HANDLER EXIT - Success');
    return { success: true };
  } catch (error) {
    console.error('❌ 🔥 🔥 🔥 ERROR HANDLING TELEGRAM WEBHOOK:', error);
    console.error('❌ 🔥 🔥 🔥 ERROR STACK:', error.stack);
    throw error;
  }
}

async function handleGifSelection(chatId, animation) {
  try {
    const { updateBotConfig } = await import('../database/queries.js');
    const { clearUserState } = await import('./keyboards.js');
    const { KEYBOARDS } = await import('./keyboards.js');
    
    // Store the file_id instead of URL
    const gifFileId = animation.file_id;
    
    await updateBotConfig(chatId, { 
      custom_gif_url: null, // Clear URL
      custom_gif_file_id: gifFileId // Store file_id
    });
    
    await sendTelegramMessage(chatId, 
      `✅ <b>¡GIF de Telegram seleccionado exitosamente!</b>\n\n` +
      `🎬 Tu GIF personalizado ha sido guardado\n` +
      `📱 Seleccionado desde tu librería de Telegram\n\n` +
      `¡Este GIF se enviará antes de cada alerta de compra! 🎯`,
      "HTML",
      KEYBOARDS.GIF_SUCCESS
    );
    
    clearUserState(chatId);
    
  } catch (error) {
    console.error('Error handling GIF selection:', error);
    await sendTelegramMessage(chatId, 
      '❌ Error guardando el GIF. Por favor intenta de nuevo.',
      "HTML",
      KEYBOARDS.SETTINGS_MENU
    );
  }
}

async function handleUserInput(chatId, text, userState) {
  const { addWatchedToken, updateBotConfig } = await import('../database/queries.js');
  const { sendTelegramMessage } = await import('./telegram.js');
  const { KEYBOARDS, setUserState, USER_STATES } = await import('./keyboards.js');
  
  try {
    switch (userState.state) {
      case USER_STATES.ADDING_TOKEN_WAITING_ADDRESS:
        const { chain } = userState.data;
        const contractAddress = text.trim();
        
        // Basic validation
        if (contractAddress.length < 10) {
          await sendTelegramMessage(chatId, '❌ Invalid contract address. Please send a valid contract address.');
          return;
        }
        
        const success = await addWatchedToken(chatId, chain, contractAddress);
        
        if (success) {
          await sendTelegramMessage(chatId, 
            `✅ <b>Token Added Successfully!</b>\n\n` +
            `🔗 Chain: <b>${chain}</b>\n` +
            `📄 Contract: <code>${contractAddress}</code>\n\n` +
            `I'll now monitor purchases for this token! 🎯`,
            "HTML",
            KEYBOARDS.TOKEN_SUCCESS
          );
        } else {
          await sendTelegramMessage(chatId, 
            `⚠️ <b>Token Already Monitored</b>\n\n` +
            `This token is already being monitored on ${chain}.`,
            "HTML",
            KEYBOARDS.TOKEN_MENU
          );
        }
        
        clearUserState(chatId);
        break;
        
      case USER_STATES.SETTING_GIF_WAITING_URL:
        const gifUrl = text.trim();
        
        // Basic URL validation
        if (!gifUrl.startsWith('http')) {
          await sendTelegramMessage(chatId, '❌ Please send a valid URL starting with http:// or https://');
          return;
        }
        
        await updateBotConfig(chatId, { custom_gif_url: gifUrl });
        await sendTelegramMessage(chatId, 
          `✅ <b>Custom GIF Set Successfully!</b>\n\n` +
          `🎬 GIF URL: <a href="${gifUrl}">Preview</a>\n\n` +
          `This GIF will be sent before each purchase alert! 🎯`,
          "HTML",
          KEYBOARDS.GIF_SUCCESS
        );
        
        clearUserState(chatId);
        break;
        
      case USER_STATES.SETTING_EMOJI_WAITING_INPUT:
        const emoji = text.trim();
        
        // Basic emoji validation (check if it's a single character and likely an emoji)
        if (emoji.length > 10) {
          await sendTelegramMessage(chatId, '❌ Please send a single emoji.');
          return;
        }
        
        await updateBotConfig(chatId, { custom_emoji: emoji });
        await sendTelegramMessage(chatId, 
          `✅ <b>Custom Emoji Set Successfully!</b>\n\n` +
          `😊 Emoji: ${emoji}\n\n` +
          `This emoji will be used in purchase alerts! 🎯`,
          "HTML",
          KEYBOARDS.SETTINGS_SUCCESS
        );
        
        clearUserState(chatId);
        break;
        
      case 'setting_min_amount':
        const minAmount = parseFloat(text.trim());
        
        if (isNaN(minAmount) || minAmount < 0) {
          await sendTelegramMessage(chatId, '❌ Please send a valid number (0 or greater).');
          return;
        }
        
        const config = await getBotConfig(chatId);
        const updatedFilters = { 
          ...(config.purchase_filters || {}), 
          min_usd_amount: minAmount 
        };
        
        await updateBotConfig(chatId, { purchase_filters: updatedFilters });
        await sendTelegramMessage(chatId, 
          `✅ <b>Minimum Amount Set!</b>\n\n` +
          `💰 <b>New Setting:</b> $${minAmount.toLocaleString()}\n\n` +
          `${minAmount > 0 ? 
            `Only purchases of $${minAmount.toLocaleString()}+ will trigger alerts.` :
            'All purchases will trigger alerts (no minimum).'
          }\n\n` +
          `<i>You can change this anytime in settings.</i>`,
          "HTML",
          KEYBOARDS.SETTINGS_SUCCESS
        );
        
        clearUserState(chatId);
        break;
        
      case 'setting_quiet_hours':
        const input = text.trim().toLowerCase();
        
        if (input === 'off' || input === 'disable') {
          const config = await getBotConfig(chatId);
          const updatedFilters = { 
            ...(config.purchase_filters || {}), 
            quiet_hours: { enabled: false, start_hour: 22, end_hour: 8, timezone: 'UTC' }
          };
          
          await updateBotConfig(chatId, { purchase_filters: updatedFilters });
          await sendTelegramMessage(chatId, 
            `✅ <b>Quiet Hours Disabled</b>\n\n` +
            `🔔 You'll now receive alerts 24/7.\n\n` +
            `<i>You can re-enable quiet hours anytime in settings.</i>`,
            "HTML",
            KEYBOARDS.SETTINGS_SUCCESS
          );
        } else {
          const match = input.match(/^(\d{1,2})-(\d{1,2})$/);
          if (!match) {
            await sendTelegramMessage(chatId, '❌ Invalid format. Please use format like "22-8" or send "off" to disable.');
            return;
          }
          
          const startHour = parseInt(match[1]);
          const endHour = parseInt(match[2]);
          
          if (startHour < 0 || startHour > 23 || endHour < 0 || endHour > 23) {
            await sendTelegramMessage(chatId, '❌ Hours must be between 0-23. Example: "22-8" for 22:00 to 08:00.');
            return;
          }
          
          const config = await getBotConfig(chatId);
          const updatedFilters = { 
            ...(config.purchase_filters || {}), 
            quiet_hours: { 
              enabled: true, 
              start_hour: startHour, 
              end_hour: endHour, 
              timezone: 'UTC' 
            }
          };
          
          await updateBotConfig(chatId, { purchase_filters: updatedFilters });
          await sendTelegramMessage(chatId, 
            `✅ <b>Quiet Hours Configured!</b>\n\n` +
            `⏰ <b>Quiet Period:</b> ${startHour}:00 - ${endHour}:00 UTC\n\n` +
            `🔇 No purchase alerts will be sent during these hours.\n` +
            `🔔 Normal alerts will resume outside this period.\n\n` +
            `<i>You can modify or disable this anytime in settings.</i>`,
            "HTML",
            KEYBOARDS.SETTINGS_SUCCESS
          );
        }
        
        clearUserState(chatId);
        break;
        
      default:
        console.log(`Unknown user state: ${userState.state}`);
        clearUserState(chatId);
    }
  } catch (error) {
    console.error('Error handling user input:', error);
    await sendTelegramMessage(chatId, '❌ An error occurred. Please try again.', { reply_markup: KEYBOARDS.MAIN_MENU });
    clearUserState(chatId);
  }
}

async function handleChatTypeDetection(chat) {
  try {
    const { getBotConfig, updateBotConfig } = await import('../database/queries.js');
    
    console.log(`🔍 Chat detection - ID: ${chat.id}, Type: ${chat.type}, Title: ${chat.title || 'N/A'}`);
    
    // Si es un grupo o supergrupo, configurar automáticamente como target
    if (chat.type === 'group' || chat.type === 'supergroup') {
      console.log(`👥 Grupo detectado: ${chat.title} (${chat.id})`);
      
      // Obtener configuración actual
      const config = await getBotConfig(chat.id);
      
      // Si no tiene target_group_id configurado, usar este grupo
      if (!config.target_group_id) {
        await updateBotConfig(chat.id, { 
          target_group_id: chat.id,
          auto_send_to_group: true 
        });
        console.log(`✅ Grupo configurado automáticamente como target: ${chat.id}`);
      }
    } else if (chat.type === 'private') {
      console.log(`👤 Chat privado detectado: ${chat.id}`);
      
      // En chats privados, el target es el mismo chat
      const config = await getBotConfig(chat.id);
      if (!config.target_group_id) {
        await updateBotConfig(chat.id, { 
          target_group_id: chat.id,
          auto_send_to_group: true 
        });
        console.log(`✅ Chat privado configurado: ${chat.id}`);
      }
    }
  } catch (error) {
    console.error('❌ Error en detección de tipo de chat:', error);
  }
}
export async function initializeTelegramBot() {
  console.log('');
  console.log('='.repeat(50));
  console.log('🤖 Starting Telegram bot initialization...');
  console.log('='.repeat(50));
  console.log('🌐 Running on Railway:', !!process.env.RAILWAY_STATIC_URL);
  console.log('🌐 Port:', process.env.PORT);
  
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    console.error('❌ TELEGRAM_BOT_TOKEN not set - bot will not function');
    console.error('   Please check your .env file');
    console.error('   Railway environment variables:', Object.keys(process.env).length);
    return;
  }
  
  console.log('✅ TELEGRAM_BOT_TOKEN found in environment');
  console.log('🔍 Environment check passed');
  console.log('🔍 All env vars count:', Object.keys(process.env).length);
  
  // Clean and validate the token format
  const botToken = process.env.TELEGRAM_BOT_TOKEN.trim();
  console.log('🔍 Raw token length:', botToken.length);
  console.log('🔍 Token starts with:', botToken.substring(0, 10) + '...');
  console.log('🔍 Token contains colon:', botToken.includes(':'));
  
  if (!botToken.includes(':')) {
    console.error('❌ Invalid bot token format - should be BOT_ID:TOKEN');
    console.error('   Example: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz');
    console.error('   Current token preview:', botToken.substring(0, 20) + '...');
    return;
  }
  
  console.log('✅ Token contains colon separator');
  
  const [botId, tokenPart] = botToken.split(':');
  console.log('🔍 Bot ID:', botId);
  console.log('🔍 Token part length:', tokenPart?.length || 0);
  
  if (!botId || !tokenPart || botId.length < 8 || tokenPart.length < 30) {
    console.error('❌ Invalid bot token format');
    console.error('   Bot ID should be at least 8 digits');
    console.error('   Token part should be at least 30 characters');
    console.error('   Current Bot ID length:', botId?.length || 0);
    console.error('   Current Token part length:', tokenPart?.length || 0);
    return;
  }
  
  console.log('✅ Token format validation passed');
  
  if (process.env.TELEGRAM_BOT_TOKEN === 'your_telegram_bot_token') {
    console.error('❌ TELEGRAM_BOT_TOKEN is still set to placeholder value');
    console.error('   Please update your .env file with a real bot token');
    return;
  }
  
  console.log('✅ Token is not placeholder value');
  
  // Test the bot token first
  try {
    console.log('🔍 Testing bot token...');
    console.log('🔗 Bot ID:', botId);
    console.log('🔗 Token preview:', tokenPart.substring(0, 10) + '...');
    console.log('🔗 Full token format: BOT_ID:TOKEN ✅');
    console.log('🔗 Making test request to Telegram API...');
    
    const TELEGRAM_API_URL = buildTelegramApiUrl();
    if (!TELEGRAM_API_URL) {
      console.error('❌ Failed to build Telegram API URL');
      console.error('❌ Token used for URL:', botToken.substring(0, 20) + '...');
      return;
    }
    
    console.log('🔗 API URL built successfully');
    console.log('🔗 API URL preview:', TELEGRAM_API_URL.substring(0, 50) + '...');
    console.log('📡 Making request to Telegram API...');
    
    const response = await axios.get(`${TELEGRAM_API_URL}/getMe`, {
      timeout: 10000,
      headers: {
        'User-Agent': 'BuyXanBot/1.0'
      }
    });
    console.log('📡 API Response status:', response.status);
    console.log('📡 API Response data:', JSON.stringify(response.data, null, 2));
    
    if (response.data.ok) {
      console.log('✅ Bot token is valid!');
      console.log(`🤖 Bot info:`, response.data.result);
      console.log(`🤖 Bot username: @${response.data.result.username}`);
      console.log(`🤖 Bot name: ${response.data.result.first_name}`);
    } else {
      console.error('❌ Invalid bot token:', response.data);
      console.error('❌ Error description:', response.data.description);
      return;
    }
  } catch (error) {
    console.error('❌ Error testing bot token:', error.message);
    if (error.response) {
      console.error('❌ HTTP Status:', error.response.status);
      console.error('❌ Response data:', error.response.data);
    }
    if (error.code) {
      console.error('❌ Error code:', error.code);
    }
    console.error('❌ Error stack:', error.stack);
    return;
  }
  
  // Clear any existing webhook and start polling
  console.log('🔄 Clearing webhook...');
  try {
    await setTelegramWebhook('');
    console.log('✅ Webhook cleared successfully');
  } catch (error) {
    console.error('⚠️ Error clearing webhook:', error.message);
  }
  
  // Start polling immediately
  console.log('🔄 Starting Telegram polling...');
  startPolling();
  
  console.log('✅ Telegram bot initialized');
  console.log('📡 Using polling mode (no webhook required)');
  console.log('👂 Bot is now listening for messages...');
}