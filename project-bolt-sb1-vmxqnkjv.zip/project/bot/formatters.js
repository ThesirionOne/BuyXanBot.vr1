import { SUPPORTED_CHAINS, MESSAGE_TEMPLATES } from './config.js';
import { getCryptoPrices } from './free-apis.js';
import { sendTelegramRequest } from './telegram.js';

// ASCII Art for massive purchases
const WHALE_ASCII = `
🐋 ▄██████▄   ▄█     █▄     ▄█    █▄     ▄████████  ▄█          ▄████████ 
🐋 ███    ███ ███     ███   ███    ███   ███    ███ ███         ███    ███ 
🐋 ███    ███ ███     ███   ███    ███   ███    ███ ███         ███    █▀  
🐋 ███    ███ ███     ███  ▄███▄▄▄▄███▄▄ ███    ███ ███        ▄███▄▄▄     
🐋 ███    ███ ███     ███ ▀▀███▀▀▀▀███▀  ███    ███ ███       ▀▀███▀▀▀     
🐋 ███    ███ ███     ███   ███    ███   ███    ███ ███         ███    █▄  
🐋 ███    ███ ███ ▄█▄ ███   ███    ███   ███    ███ ███▌    ▄   ███    ███ 
🐋  ▀██████▀   ▀███▀███▀    ███    █▀    ████████▀  █████▄▄██   ██████████ 
`;

const BIG_BUY_ASCII = `
🚀 ██████╗ ██╗ ██████╗     ██████╗ ██╗   ██╗██╗   ██╗
🚀 ██╔══██╗██║██╔════╝     ██╔══██╗██║   ██║╚██╗ ██╔╝
🚀 ██████╔╝██║██║  ███╗    ██████╔╝██║   ██║ ╚████╔╝ 
🚀 ██╔══██╗██║██║   ██║    ██╔══██╗██║   ██║  ╚██╔╝  
🚀 ██████╔╝██║╚██████╔╝    ██████╔╝╚██████╔╝   ██║   
🚀 ╚═════╝ ╚═╝ ╚═════╝     ╚═════╝  ╚═════╝    ╚═╝   
`;

// Progress bar generator
function generateProgressBar(percentage, length = 10) {
  const filled = Math.round((percentage / 100) * length);
  const empty = length - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

// Time ago formatter
function getTimeAgo(timestamp) {
  const now = Date.now();
  const diff = now - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  
  if (seconds < 30) return "JUST NOW";
  if (seconds < 60) return `${seconds}s ago`;
  if (minutes < 60) return `${minutes}m ago`;
  return `${Math.floor(minutes / 60)}h ago`;
}

// Momentum indicators
function getMomentumIndicator(volume24h, priceChange24h) {
  if (volume24h > 100000 && priceChange24h > 50) return "🔥 HOT";
  if (volume24h > 50000 && priceChange24h > 20) return "⚡ TRENDING";
  if (priceChange24h > 100) return "🚀 PUMPING";
  if (volume24h > 20000) return "💎 DIAMOND HANDS";
  return "📈 ACTIVE";
}

// Purchase ranking
function getPurchaseRanking(usdValue) {
  if (usdValue >= 50000) return "🏆 TOP 0.1%";
  if (usdValue >= 20000) return "⭐ TOP 1%";
  if (usdValue >= 10000) return "💎 TOP 5%";
  if (usdValue >= 5000) return "🔥 TOP 10%";
  if (usdValue >= 1000) return "⚡ TOP 25%";
  return "📊 ACTIVE";
}

// Badge generator
function getBadges(purchase, config) {
  const badges = [];
  const { usd_value, volume_24h, price_change_24h } = purchase;
  
  if (usd_value >= 50000) badges.push("🐋 WHALE");
  if (usd_value >= 10000) badges.push("⭐ VIP");
  if (volume_24h > 100000) badges.push("🔥 HOT");
  if (price_change_24h > 100) badges.push("🚀 MOON");
  if (usd_value >= 1000) badges.push("💎 DIAMOND");
  
  return badges.length > 0 ? badges.join(" ") : "📈 ACTIVE";
}

// Gradient effect with emojis
function createGradientLine(usdValue) {
  if (usdValue >= 50000) return "🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥";
  if (usdValue >= 20000) return "🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀";
  if (usdValue >= 10000) return "💎💎💎💎💎💎💎💎💎";
  if (usdValue >= 5000) return "⚡⚡⚡⚡⚡⚡";
  return "🟢🟢🟢";
}

// 📍 AQUÍ ESTÁN LOS TEMPLATES - PUEDES MODIFICAR CUALQUIER TEXTO

export function formatPurchaseMessage(purchase, config) {
  const template = MESSAGE_TEMPLATES[config.message_template] || MESSAGE_TEMPLATES.default;
  const showFields = config.show_fields || {};
  
  switch (template.layout) {
    case 'compact':
      return formatCompactMessage(purchase, config, showFields);
    case 'whale':
      // 🐋 TEMPLATE WHALE - Línea ~150
      return formatWhaleMessage(purchase, config, showFields);
    case 'promotional':
      // 🚀 TEMPLATE PROMOCIONAL - Línea ~200  
      return formatMarketingMessage(purchase, config, showFields);
    case 'data_heavy':
      // 📊 TEMPLATE TÉCNICO - Línea ~250
      return formatTechnicalMessage(purchase, config, showFields);
    default:
      // 🤖 TEMPLATE CLÁSICO/DEFAULT - Línea ~100
      return formatDefaultMessage(purchase, config, showFields);
  }
}

function formatDefaultMessage(purchase, config, showFields) {
  const {
    token_name,
    token_symbol,
    chain,
    native_amount,
    token_amount,
    buyer_address,
    txn_hash,
    token_address,
    price_usd,
    market_cap_usd,
    total_supply,
    volume_24h,
    price_change_24h,
    timestamp
  } = purchase;
  
  const chainConfig = SUPPORTED_CHAINS[chain];
  const nativeSymbol = chainConfig?.symbol || 'TOKEN';
  const explorerUrl = chainConfig.explorer;
  
  // Use the USD value from the purchase data if available
  const usdValue = purchase.usd_value || (native_amount * 1000); // fallback calculation
  
  // Custom emoji count based on purchase size
  const customEmoji = config.custom_emoji || '🟢';
  
  // Get visual elements
  const timeAgo = getTimeAgo(timestamp);
  const momentum = getMomentumIndicator(volume_24h || 0, price_change_24h || 0);
  const ranking = getPurchaseRanking(usdValue);
  const badges = getBadges({ usd_value: usdValue, volume_24h: volume_24h || 0, price_change_24h: price_change_24h || 0 }, config);
  const gradientLine = createGradientLine(usdValue);
  
  // Calculate supply percentage (mock calculation)
  const supplyPercentage = ((token_amount / total_supply) * 100).toFixed(4);
  const progressBar = generateProgressBar(Math.min(parseFloat(supplyPercentage) * 1000, 100));
  
  // Dynamic header with ASCII art for massive purchases
  let headerSection = '';
  if (usdValue >= 10000) {
    headerSection = WHALE_ASCII + '\n🐋🐋🐋 WHALE ALERT 🐋🐋🐋\n';
  } else if (usdValue >= 5000) {
    headerSection = BIG_BUY_ASCII + '\n🚀🚀🚀 BIG BUY DETECTED 🚀🚀🚀\n';
  } else {
    headerSection = `${gradientLine}\n💎 NEW ${token_symbol} BUY 💎\n${gradientLine}\n`;
  }
  
  // Format addresses for display
  const shortBuyerAddress = formatAddress(buyer_address);
  const shortTokenAddress = formatAddress(token_address);
  
  // Build chart and trade links
  const chartLink = buildChartLink(chain, token_address);
  const tradeLink = buildTradeLink(chain, token_address);
  
  // Create the INCREDIBLE compact message
  let message = headerSection;
  message += `\n🎯 <b>${token_name} (${token_symbol})</b> | ${timeAgo} | ${badges}\n`;
  message += `${momentum} | ${ranking}\n\n`;
  
  // Purchase details - more compact
  message += `💰 ${native_amount.toFixed(4)} ${nativeSymbol} ($${usdValue.toLocaleString('en-US', {maximumFractionDigits: 2})}) | `;
  message += `🪙 ${token_amount.toLocaleString('en-US', {maximumFractionDigits: 0})} ${token_symbol}\n`;
  message += `📊 Supply: ${supplyPercentage}% ${progressBar}\n\n`;
  
  // Token information - compact format
  message += `📈 Price: $${(price_usd || 0).toFixed(8)} | MC: $${market_cap_usd.toLocaleString('en-US', {maximumFractionDigits: 0})}\n`;
  message += `📊 24h Vol: $${(volume_24h || 0).toLocaleString('en-US', {maximumFractionDigits: 0})} | Change: ${(price_change_24h || 0).toFixed(1)}%\n`;
  message += `⛓️ ${chainConfig.name} | <code>${shortTokenAddress}</code>\n\n`;
  
  // Buyer information - compact
  message += `👤 <a href="${explorerUrl}/address/${buyer_address}">${shortBuyerAddress}</a> | `;
  message += `<a href="${explorerUrl}/tx/${txn_hash}">View TX</a>\n\n`;
  
  // Footer with custom branding
  message += `🤖 <a href="https://t.me/BuyXanBot">BuyXanBot</a> is a development from <a href="https://t.me/XandersOGCALLS">TeamXanders</a> & <a href="https://thesirion.io">Thesirion</a>`;
  
  return message;
}

function formatCompactMessage(purchase, config, showFields) {
  const { token_name, token_symbol, chain, native_amount, usd_value } = purchase;
  const chainConfig = SUPPORTED_CHAINS[chain];
  const customEmoji = config.custom_emoji || '🟢';
  
  return `${customEmoji} <b>${token_symbol}</b> compra: $${usd_value.toLocaleString()} (${native_amount.toFixed(3)} ${chainConfig.symbol}) en ${chain}`;
}

// Create inline keyboard for purchase messages
export function createPurchaseKeyboard(tokenAddress, chain) {
  const chartLink = buildChartLink(chain, tokenAddress);
  const tradeLink = buildTradeLink(chain, tokenAddress);
  
  return {
    inline_keyboard: [
      [
        { text: '🏆 TOP TOKENS', callback_data: 'menu_top_tokens' },
        { text: '📊 Chart', url: chartLink }
      ],
      [
        { text: '🦄 Trade Now', url: tradeLink },
        { text: '👥 TeamXanders', url: 'https://t.me/XandersOGCALLS' }
      ]
    ]
  };
}

function formatWhaleMessage(purchase, config, showFields) {
  const {
    token_name, token_symbol, chain, native_amount, usd_value,
    buyer_address, token_address
  } = purchase;
  
  const chainConfig = SUPPORTED_CHAINS[chain];
  const shortBuyerAddress = formatAddress(buyer_address);
  const chartLink = buildChartLink(chain, token_address);
  const tradeLink = buildTradeLink(chain, token_address);
  
  return `🐋 <b>NEW ${token_symbol} WHALE</b> 🐋

💎 <b>${token_name}</b> (${token_symbol})
💰 <b>$${usd_value.toLocaleString()}</b> (${native_amount.toFixed(3)} ${chainConfig.symbol})

👤 BUYER: <a href="${chainConfig.explorer}/address/${buyer_address}">${shortBuyerAddress}</a>
⛓️ CHAIN: ${chainConfig.name}

📈 <a href="${chartLink}">CHART</a> | 🦄 <a href="${tradeLink}">TRADE</a>

🤖 <a href="https://t.me/BuyXanBot">BuyXanBot</a> is a development from <a href="https://t.me/XandersOGCALLS">TeamXanders</a> & <a href="https://thesirion.io">Thesirion</a>`;
}

function formatMarketingMessage(purchase, config, showFields) {
  const {
    token_name, token_symbol, chain, native_amount, usd_value,
    market_cap_usd, token_address
  } = purchase;
  
  const chainConfig = SUPPORTED_CHAINS[chain];
  const customEmoji = config.custom_emoji || '🚀';
  const emojiCount = Math.min(Math.floor(usd_value / 100), 10) + 3;
  const emojis = customEmoji.repeat(emojiCount);
  const chartLink = buildChartLink(chain, token_address);
  const tradeLink = buildTradeLink(chain, token_address);
  
  return `${emojis} <b>NEW ${token_symbol} BUY!</b> ${emojis}

🎯 <b>${token_name}</b> it is on FIRE! 🔥
💰 Buy from <b>$${usd_value.toLocaleString()}</b>
📊 Market Cap: <b>$${market_cap_usd.toLocaleString()}</b>
⛓️ En ${chainConfig.name}

🚀 <b>¡DO NOT MISS THE TRAIN!</b>

📈 <a href="${chartLink}">CHART</a>
🦄 <a href="${tradeLink}">BUY NOW!</a>

${emojis} <a href="https://t.me/BuyXanBot">BuyXanBot</a> is a development from <a href="https://t.me/XandersOGCALLS">TeamXanders</a> & <a href="https://thesirion.io">Thesirion</a> ${emojis}`;
}

function formatTechnicalMessage(purchase, config, showFields) {
  const {
    token_name, token_symbol, chain, native_amount, token_amount,
    buyer_address, txn_hash, token_address, price_usd, market_cap_usd,
    total_supply, usd_value
  } = purchase;
  
  const chainConfig = SUPPORTED_CHAINS[chain];
  const shortBuyerAddress = formatAddress(buyer_address);
  const walletBalance = token_amount * (1 + Math.random() * 0.5);
  const positionPercent = (walletBalance / total_supply) * 100;
  
  return `📊 <b>NEW ${token_symbol} BUY - TECHNICAL</b>

<b>🔍 TRANSACTION DATA:</b>
• Token: ${token_name} (${token_symbol})
• Value: $${usd_value.toLocaleString()} USD
• Amount: ${native_amount.toFixed(6)} ${chainConfig.symbol}
• Tokens: ${token_amount.toLocaleString()} ${token_symbol}
• Hash: <code>${txn_hash.slice(0, 20)}...</code>

<b>📈 MÉTRICAS DE MERCADO:</b>
• Price: $${(price_usd || 0).toFixed(8)}
• Market Cap: $${market_cap_usd.toLocaleString()}
• Supply: ${total_supply.toLocaleString()}
• Position: +${positionPercent.toFixed(3)}%

<b>👤 WALLET ANALYSIS:</b>
• Adress: <a href="${chainConfig.explorer}/address/${buyer_address}">${shortBuyerAddress}</a>
• Chain: ${chainConfig.name} (${chain})
• Contract: <code>${token_address}</code>

<i>📊 <a href="https://t.me/BuyXanBot">BuyXanBot</a> is a development from <a href="https://t.me/XandersOGCALLS">TeamXanders</a> & <a href="https://thesirion.io">Thesirion</a></i>`;
}

// Función para aplicar filtros de compra
export function shouldSendPurchaseAlert(purchase, config) {
  const filters = config.purchase_filters || {};
  
  // Filtro de monto mínimo USD
  if (filters.min_usd_amount > 0 && purchase.usd_value < filters.min_usd_amount) {
    console.log(`🚫 Filtered buy: $${purchase.usd_value} < $${filters.min_usd_amount} (min)`);
    return false;
  }
  
  // Filtro de horario silencioso
  if (filters.quiet_hours?.enabled) {
    const now = new Date();
    const currentHour = now.getUTCHours(); // Usar UTC por simplicidad
    const startHour = filters.quiet_hours.start_hour;
    const endHour = filters.quiet_hours.end_hour;
    
    let isQuietTime = false;
    if (startHour <= endHour) {
      // Mismo día (ej: 22:00 - 08:00 del siguiente día)
      isQuietTime = currentHour >= startHour && currentHour < endHour;
    } else {
      // Cruza medianoche (ej: 22:00 - 08:00)
      isQuietTime = currentHour >= startHour || currentHour < endHour;
    }
    
    if (isQuietTime) {
      console.log(`🔇 Filtered buy: Silence Hour (${currentHour}:00 UTC)`);
      return false;
    }
  }
  
  // Modo ballenas (solo compras grandes)
  if (filters.whale_mode && purchase.usd_value < 1000) {
    console.log(`🐋 Filtered buy, whales mode ON, $${purchase.usd_value} < $1000`);
    return false;
  }
  
  // TODO: Implementar filtro de balance de wallet (requiere API adicional)
  // TODO: Implementar límite de alertas por hora (requiere tracking temporal)
  
  return true;
}

function formatAddress(address) {
  if (!address) return 'N/A';
  
  if (address.length <= 12) {
    return address;
  }
  
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function buildChartLink(chain, tokenAddress) {
  const baseUrl = 'https://www.geckoterminal.com';
  
  switch (chain) {
    case 'ETH':
      return `${baseUrl}/eth/pools/${tokenAddress}`;
    case 'SOLANA':
      return `${baseUrl}/solana/pools/${tokenAddress}`;
    case 'BNB':
      return `${baseUrl}/bsc/pools/${tokenAddress}`;
    case 'BASE':
      return `${baseUrl}/base/pools/${tokenAddress}`;
    default:
      return baseUrl;
  }
}

function buildTradeLink(chain, tokenAddress) {
  const uniswapBase = 'https://app.uniswap.org/swap';
  
  switch (chain) {
    case 'ETH':
      return `${uniswapBase}?chain=ethereum&outputCurrency=${tokenAddress}`;
    case 'SOLANA':
      return `https://jup.ag/swap/SOL-${tokenAddress}`;
    case 'BNB':
      return `https://pancakeswap.finance/swap?outputCurrency=${tokenAddress}`;
    case 'BASE':
      return `${uniswapBase}?chain=base&outputCurrency=${tokenAddress}`;
    default:
      return uniswapBase;
  }
}