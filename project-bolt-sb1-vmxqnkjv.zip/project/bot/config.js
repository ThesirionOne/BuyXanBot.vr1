export const SUPPORTED_CHAINS = {
  ETH: {
    name: 'Ethereum',
    symbol: 'ETH',
    explorer: 'https://etherscan.io',
    dexscreener: 'ethereum',
    coingecko: 'ethereum'
  },
  SOLANA: {
    name: 'Solana',
    symbol: 'SOL',
    explorer: 'https://solscan.io',
    dexscreener: 'solana',
    coingecko: 'solana'
  },
  BNB: {
    name: 'BNB Chain',
    symbol: 'BNB',
    explorer: 'https://bscscan.com',
    dexscreener: 'bsc',
    coingecko: 'binance-smart-chain'
  },
  BASE: {
    name: 'Base',
    symbol: 'ETH',
    explorer: 'https://basescan.org',
    dexscreener: 'base',
    coingecko: 'base'
  }
};

export const TELEGRAM_COMMANDS = {
  START: '/start',
  HELP: '/help',
  ADD_TOKEN: '/addtoken',
  REMOVE_TOKEN: '/removetoken',
  LIST_TOKENS: '/listtokens',
  SET_GIF: '/setgif',
  SET_EMOJI: '/setemoji',
  TEST: '/test'
};

export const DEFAULT_CONFIG = {
  watched_tokens: {
    ETH: [],
    SOLANA: [],
    BNB: [],
    BASE: []
  },
  custom_gif_url: null,
  custom_gif_file_id: null,
  custom_emoji: '🟢',
  message_template: 'default',
  bot_active: false, // Bot starts inactive until user clicks START BUY BOT
  setup_completed: false, // Track if initial setup is done
  show_fields: {
    token_info: true,
    buyer_info: true,
    transaction_info: true,
    market_data: true,
    quick_links: true,
    branding: true
  },
  purchase_filters: {
    min_usd_amount: 150,
    min_wallet_balance_usd: 0,
    whale_mode: false,
    quiet_hours: {
      enabled: false,
      start_hour: 22,
      end_hour: 8,
      timezone: 'UTC'
    },
    max_alerts_per_hour: 0
  },
  auto_send_to_group: true,
  target_group_id: null // Se configurará automáticamente cuando se use en un grupo
};

// Plantillas de mensaje personalizables
export const MESSAGE_TEMPLATES = {
  default: {
    name: '🤖 Clásico',
    description: 'Formato completo con toda la información',
    emoji_style: 'mixed',
    layout: 'detailed'
  },
  minimal: {
    name: '📱 Minimalista',
    description: 'Solo información esencial, formato compacto',
    emoji_style: 'minimal',
    layout: 'compact'
  },
  whale: {
    name: '🐋 Ballenas',
    description: 'Enfocado en compras grandes, estilo premium',
    emoji_style: 'premium',
    layout: 'whale'
  },
  promo: {
    name: '🚀 Promocional',
    description: 'Diseñado para promocionar tokens, llamativo',
    emoji_style: 'promotional',
    layout: 'promotional'
  },
  technical: {
    name: '📊 Técnico',
    description: 'Datos técnicos detallados, para traders avanzados',
    emoji_style: 'technical',
    layout: 'data_heavy'
  }
};

// Configuración de campos mostrados
export const MESSAGE_FIELDS = {
  token_info: {
    name: '🪙 Información del Token',
    description: 'Nombre, símbolo, precio',
    default: true
  },
  buyer_info: {
    name: '👤 Información del Comprador',
    description: 'Dirección del comprador, enlaces',
    default: true
  },
  transaction_info: {
    name: '💰 Detalles de Transacción',
    description: 'Cantidad, valor USD, hash',
    default: true
  },
  market_data: {
    name: '📊 Datos de Mercado',
    description: 'Market cap, supply, precio',
    default: true
  },
  quick_links: {
    name: '⚡ Enlaces Rápidos',
    description: 'Gráficos, trading, explorer',
    default: true
  },
  branding: {
    name: '🤖 Branding del Bot',
    description: 'Firma y enlaces del bot',
    default: true
  }
};

// TOP TOKENS - Fácil de customizar para promociones
export const TOP_TOKENS = {
  ETH: [
    {
      name: 'MANYU',
      symbol: 'MANYU',
      contract: '0x95af4af910c28e8ece4512bfe46f1f33687424ce',
      description: '🐸 The Only Black Shiba Inu, MEME OF THE WEEK',
      website: 'https://manyushiba.com/',
      promoted: true
    },
    {
      name: 'Zeus Dog',
      symbol: 'ZEUS',
      contract: '0x0f7dc5d02cc1e1f5ee47854d534d332a1081ccc8',
      description: '🐕 Meme Of The Millenium, MEME OF TODAY',
      website: 'https://www.zeuscoin.vip/',
      promoted: true
    },
    {
      name: 'Wojak',
      symbol: 'WOJAK',
      contract: '0x5026F006B85729a8b14553FAE6af249aD16c9aaB',
      description: '😔 Feel the market emotions',
      website: 'https://wojak.com',
      promoted: false
    }
  ],
  SOLANA: [
    {
      name: 'Bonk',
      symbol: 'BONK',
      contract: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
      description: '🐕 Solana\'s first dog coin',
      website: 'https://bonkcoin.com',
      promoted: true
    },
    {
      name: 'Dogwifhat',
      symbol: 'WIF',
      contract: 'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm',
      description: '🐕‍🦺 Dog with a hat on Solana',
      website: 'https://dogwifcoin.org',
      promoted: false
    }
  ],
  BNB: [
    {
      name: 'SafeMoon',
      symbol: 'SAFEMOON',
      contract: '0x42981d0bfbAf196529376EE702F2a9Eb9092fcB5',
      description: '🚀 To the moon safely',
      website: 'https://safemoon.net',
      promoted: false
    },
    {
      name: 'BabyDoge',
      symbol: 'BABYDOGE',
      contract: '0xc748673057861a797275CD8A068AbB95A902e8de',
      description: '🐶 The baby of Dogecoin',
      website: 'https://babydogecoin.com',
      promoted: false
    }
  ],
  BASE: [
    {
      name: 'Thesirion',
      symbol: 'TSO',
      contract: '0x7772b39661b87a98521193b9f18f87cfabe401fa',
      description: '🎭 Best Crypto Creative Agency',
      website: 'https://thesirion.io',
      promoted: true
    }
  ]
};
