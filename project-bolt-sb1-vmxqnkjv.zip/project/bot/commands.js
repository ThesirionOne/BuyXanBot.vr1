import { sendTelegramMessage } from './telegram.js';
import { KEYBOARDS } from './keyboards.js';
import { 
  getBotConfig, 
  updateBotConfig, 
  addWatchedToken, 
  removeWatchedToken,
  getWatchedTokens 
} from '../database/queries.js';
import { SUPPORTED_CHAINS, TELEGRAM_COMMANDS } from './config.js';

// Añadir comando de prueba

export async function handleTelegramCommand(chatId, text) {
  console.log(`🔧 🔥 🔥 🔥 HANDLE_TELEGRAM_COMMAND ENTRY`);
  console.log(`🔧 🔥 chatId: ${chatId}`);
  console.log(`🔧 🔥 text: ${text}`);
  
  const parts = text.split(' ');
  // Remove @username from command if present (for group usage)
  const commandPart = parts[0].split('@')[0];
  const command = commandPart.toLowerCase();
  const args = parts.slice(1);
  
  console.log(`🔧 🔥 PROCESSING COMMAND: ${command}`);
  console.log(`🔧 🔥 ARGS:`, args);
  console.log(`🔧 🔥 ORIGINAL COMMAND PART: ${parts[0]}`);
  console.log(`🔧 🔥 AFTER SPLIT: ${commandPart}`);
  console.log(`🔧 🔥 FINAL COMMAND: ${command}`);
  console.log(`🔧 🔥 TELEGRAM_COMMANDS:`, TELEGRAM_COMMANDS);
  
  switch (command) {
    case TELEGRAM_COMMANDS.START:
    case TELEGRAM_COMMANDS.HELP:
      console.log(`🔧 🔥 CALLING handleStartCommand for chat ${chatId}`);
      await handleStartCommand(chatId);
      console.log(`🔧 🔥 handleStartCommand COMPLETED for chat ${chatId}`);
      break;
    case TELEGRAM_COMMANDS.TEST:
      console.log(`🔧 🔥 CALLING handleTestCommand`);
      await handleTestCommand(chatId);
      break;
    case TELEGRAM_COMMANDS.ADD_TOKEN:
      console.log(`🔧 🔥 CALLING handleAddTokenCommand`);
      await handleAddTokenCommand(chatId, args);
      break;
    case TELEGRAM_COMMANDS.REMOVE_TOKEN:
      console.log(`🔧 🔥 CALLING handleRemoveTokenCommand`);
      await handleRemoveTokenCommand(chatId, args);
      break;
    case TELEGRAM_COMMANDS.LIST_TOKENS:
      console.log(`🔧 🔥 CALLING handleListTokensCommand`);
      await handleListTokensCommand(chatId);
      break;
    case TELEGRAM_COMMANDS.SET_GIF:
      console.log(`🔧 🔥 CALLING handleSetGifCommand`);
      await handleSetGifCommand(chatId, args);
      break;
    case TELEGRAM_COMMANDS.SET_EMOJI:
      console.log(`🔧 🔥 CALLING handleSetEmojiCommand`);
      await handleSetEmojiCommand(chatId, args);
      break;
    case '/clearrate':
      console.log(`🔧 🔥 CALLING handleClearRateCommand`);
      await handleClearRateCommand(chatId);
      break;
    case '/checkapi':
      console.log(`🔧 🔥 CALLING handleCheckApiCommand`);
      await handleCheckApiCommand(chatId);
      break;
    default:
      console.log(`🔧 🔥 UNKNOWN COMMAND: ${command}`);
      await sendTelegramMessage(chatId, 
        "❌ Unknown command. Use /help to see available commands."
      );
  }
  console.log(`🔧 🔥 🔥 🔥 HANDLE_TELEGRAM_COMMAND EXIT`);
}

async function handleStartCommand(chatId) {
  console.log('🎮 🔥 🔥 🔥 HANDLE_START_COMMAND ENTRY for chat:', chatId);
  
  try {
  console.log('🎮 🔥 Getting bot config...');
  const config = await getBotConfig(chatId);
  console.log('🎮 🔥 Config loaded:', JSON.stringify(config, null, 2));
  
  console.log('🎮 🔥 Getting watched tokens...');
  const tokens = await getWatchedTokens(chatId);
  console.log('🎮 🔥 Tokens loaded count:', tokens.length);
  console.log('🎮 🔥 Tokens data:', JSON.stringify(tokens, null, 2));
  
  // Detectar tipo de chat para el mensaje de bienvenida
  const isGroup = config.target_group_id && config.target_group_id !== chatId;
  const chatTypeText = isGroup ? 
    `📢 <b>Configurado para grupo:</b> ${config.target_group_id}\n` : 
    `💬 <b>Chat:</b> Privado\n`;
  
  console.log('🎮 🔥 Creating welcome message...');
  const welcomeMessage = `🤖 <b>Welcome to BuyXanBot!</b>

I'm your multi-chain token purchase detection bot! 🚀

<b>🎯 What I do:</b>
• Monitor token purchases in real-time
• Send instant alerts with purchase details
• Support 4 major blockchains
• Customizable notifications

<b>🔗 Supported Networks:</b>
• ETH (Ethereum)
• SOLANA (Solana)
• BNB (BNB Chain)
• BASE (Base)

<b>📊 Current Status:</b>
${chatTypeText}• Monitoring: <b>${tokens.length}</b> token(s)
• Monitoring: <b>${tokens.length}</b> token(s)
• Custom Settings: <b>${config.custom_gif_url ? 'GIF + ' : ''}${config.custom_emoji !== '🟢' ? 'Emoji' : 'Default'}</b>

<i>Use the buttons below to get started:</i>`;
  
  console.log('🎮 🔥 Welcome message created, length:', welcomeMessage.length);
  console.log('🎮 🔥 KEYBOARDS.MAIN_MENU:', JSON.stringify(KEYBOARDS.MAIN_MENU, null, 2));
  
  console.log('🎮 🔥 About to call sendTelegramMessage...');
  
  const result = await sendTelegramMessage(chatId, welcomeMessage, "HTML", KEYBOARDS.MAIN_MENU);
  console.log('🎮 🔥 Send message result:', JSON.stringify(result, null, 2));
  
  console.log('🎮 🔥 🔥 🔥 HANDLE_START_COMMAND EXIT for chat:', chatId);
  } catch (error) {
    console.error('❌ 🔥 ERROR IN handleStartCommand:', error);
    console.error('❌ 🔥 STACK TRACE:', error.stack);
    throw error;
  }
}

async function handleAddTokenCommand(chatId, args) {
  if (args.length !== 2) {
    await sendTelegramMessage(chatId, 
      "❌ <b>Invalid usage.</b>\n\n" +
      "Usage: <code>/addtoken [CHAIN] [CONTRACT_ADDRESS]</code>\n" +
      "Example: <code>/addtoken ETH 0x1234567890abcdef1234567890abcdef12345678</code>"
    );
    return;
  }
  
  const [chain, contractAddress] = args;
  const chainUpper = chain.toUpperCase();
  
  if (!SUPPORTED_CHAINS[chainUpper]) {
    await sendTelegramMessage(chatId, 
      `❌ <b>Unsupported chain:</b> ${chain}\n\n` +
      "Supported chains: ETH, SOLANA, BNB, BASE"
    );
    return;
  }
  
  try {
    const success = await addWatchedToken(chatId, chainUpper, contractAddress);
    
    if (success) {
      await sendTelegramMessage(chatId, 
        `✅ <b>Token added successfully!</b>\n\n` +
        `🔗 Chain: <b>${chainUpper}</b>\n` +
        `📄 Contract: <code>${contractAddress}</code>\n\n` +
        "I'll now monitor purchases for this token! 🎯",
        "HTML",
        KEYBOARDS.TOKEN_SUCCESS
      );
    } else {
      await sendTelegramMessage(chatId, 
        `⚠️ <b>Token already monitored</b>\n\n` +
        `This token is already being monitored in ${chainUpper}.`,
        "HTML",
        KEYBOARDS.TOKEN_MENU
      );
    }
  } catch (error) {
    console.error('Error adding token:', error);
    await sendTelegramMessage(chatId, 
      "❌ <b>Error adding token.</b>\n\nPlease try again later.",
      "HTML",
      KEYBOARDS.TOKEN_MENU
    );
  }
}

async function handleRemoveTokenCommand(chatId, args) {
  if (args.length !== 2) {
    await sendTelegramMessage(chatId, 
      "❌ <b>Invalid usage.</b>\n\n" +
      "Usage: <code>/removetoken [CHAIN] [CONTRACT_ADDRESS]</code>\n" +
      "Example: <code>/removetoken ETH 0x1234567890abcdef1234567890abcdef12345678</code>"
    );
    return;
  }
  
  const [chain, contractAddress] = args;
  const chainUpper = chain.toUpperCase();
  
  if (!SUPPORTED_CHAINS[chainUpper]) {
    await sendTelegramMessage(chatId, 
      `❌ <b>Unsupported chain:</b> ${chain}\n\n` +
      "Supported chains: ETH, SOLANA, BNB, BASE"
    );
    return;
  }
  
  try {
    const success = await removeWatchedToken(chatId, chainUpper, contractAddress);
    
    if (success) {
      await sendTelegramMessage(chatId, 
        `✅ <b>Token removed successfully!</b>\n\n` +
        `🔗 Chain: <b>${chainUpper}</b>\n` +
        `📄 Contract: <code>${contractAddress}</code>\n\n` +
        "I'll no longer monitor this token. 🗑️",
        "HTML",
        KEYBOARDS.REMOVAL_SUCCESS
      );
    } else {
      await sendTelegramMessage(chatId, 
        `⚠️ <b>Token not found</b>\n\n` +
        `This token is not being monitored on ${chainUpper}.`,
        "HTML",
        KEYBOARDS.TOKEN_MENU
      );
    }
  } catch (error) {
    console.error('Error removing token:', error);
    await sendTelegramMessage(chatId, 
      "❌ <b>Error removing token.</b>\n\nPlease try again later.",
      "HTML",
      KEYBOARDS.TOKEN_MENU
    );
  }
}

async function handleListTokensCommand(chatId) {
  try {
    const tokens = await getWatchedTokens(chatId);
    
    if (!tokens || tokens.length === 0) {
      await sendTelegramMessage(chatId, 
        "📋 <b>No tokens being monitored</b>\n\n" +
        "Use /addtoken to add tokens to monitor.\n\n" +
        "Example: <code>/addtoken ETH 0x1234567890abcdef1234567890abcdef12345678</code>"
      );
      return;
    }
    
    let message = "📋 <b>Monitored Tokens:</b>\n\n";
    
    const tokensByChain = {};
    tokens.forEach(token => {
      if (!tokensByChain[token.chain]) {
        tokensByChain[token.chain] = [];
      }
      tokensByChain[token.chain].push(token.contract_address);
    });
    
    Object.entries(tokensByChain).forEach(([chain, contracts]) => {
      message += `🔗 <b>${chain}:</b>\n`;
      contracts.forEach(contract => {
        message += `  • <code>${contract}</code>\n`;
      });
      message += "\n";
    });
    
    message += `<i>Total: ${tokens.length} token(s) monitored</i>`;
    
    await sendTelegramMessage(chatId, message);
  } catch (error) {
    console.error('Error listing tokens:', error);
    await sendTelegramMessage(chatId, 
      "❌ <b>Error fetching tokens.</b>\n\nPlease try again later."
    );
  }
}

async function handleSetGifCommand(chatId, args) {
  if (args.length !== 1) {
    await sendTelegramMessage(chatId, 
      "❌ <b>Invalid usage.</b>\n\n" +
      "Usage: <code>/setgif [GIF_URL]</code>\n" +
      "Example: <code>/setgif https://media.giphy.com/media/your-gif.gif</code>"
    );
    return;
  }
  
  const gifUrl = args[0];
  
  try {
    await updateBotConfig(chatId, { custom_gif_url: gifUrl });
    await sendTelegramMessage(chatId, 
      `✅ <b>Custom GIF set successfully!</b>\n\n` +
      `🎬 GIF URL: <a href="${gifUrl}">Preview</a>\n\n` +
      "This GIF will be sent before each purchase alert! 🎯",
      "HTML",
      KEYBOARDS.SETTINGS_SUCCESS
    );
  } catch (error) {
    console.error('Error setting GIF:', error);
    await sendTelegramMessage(chatId, 
      "❌ <b>Error setting GIF.</b>\n\nPlease try again later.",
      "HTML",
      KEYBOARDS.SETTINGS_MENU
    );
  }
}

async function handleSetEmojiCommand(chatId, args) {
  if (args.length !== 1) {
    await sendTelegramMessage(chatId, 
      "❌ <b>Invalid usage.</b>\n\n" +
      "Usage: <code>/setemoji [EMOJI]</code>\n" +
      "Example: <code>/setemoji 💰</code>"
    );
    return;
  }
  
  const emoji = args[0];
  
  try {
    await updateBotConfig(chatId, { custom_emoji: emoji });
    await sendTelegramMessage(chatId, 
      `✅ <b>Custom emoji set successfully!</b>\n\n` +
      `😊 Emoji: ${emoji}\n\n` +
      "This emoji will be used in purchase alerts! 🎯",
      "HTML",
      KEYBOARDS.SETTINGS_SUCCESS
    );
  } catch (error) {
    console.error('Error setting emoji:', error);
    await sendTelegramMessage(chatId, 
      "❌ <b>Error setting emoji.</b>\n\nPlease try again later.",
      "HTML",
      KEYBOARDS.SETTINGS_MENU
    );
  }
}

async function handleTestCommand(chatId) {
  console.log('🧪 🔥 🔥 🔥 HANDLE_TEST_COMMAND ENTRY for chat:', chatId);
  
  try {
    // Importar las funciones necesarias
    const { formatPurchaseMessage } = await import('./formatters.js');
    const { sendTelegramMessageWithGif, sendTelegramMessageWithGifFileId } = await import('./telegram.js');
    const { getBotConfig } = await import('../database/queries.js');
    
    // Obtener configuración del bot
    const config = await getBotConfig(chatId);
    
    // Crear datos de compra simulados
    const mockPurchase = {
      token_name: 'Pepe Inu',
      token_symbol: 'PEPEINU',
      chain: 'ETH',
      native_amount: 0.25,
      token_amount: 50000000,
      buyer_address: '0x742d35Cc6634C0532925a3b8D4C9db96590c6C87',
      txn_hash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
      token_address: '0x6982508145454Ce325dDbE47a25d4ec3d2311933',
      price_usd: 0.0000125,
      market_cap_usd: 2500000,
      total_supply: 1000000000000,
      usd_value: 875.50,
      timestamp: Date.now()
    };
    
    console.log('🧪 🔥 Datos de compra simulados creados:', JSON.stringify(mockPurchase, null, 2));
    
    // Formatear mensaje
    const message = formatPurchaseMessage(mockPurchase, config);
    console.log(`📝 🔥 Mensaje de prueba formateado (longitud: ${message.length})`);
    
    // Determinar chat de destino (si es grupo, enviar al grupo)
    let targetChatId = chatId;
    if (config.target_group_id && config.target_group_id !== chatId) {
      targetChatId = config.target_group_id;
      console.log(`🎯 🔥 Enviando prueba al grupo configurado: ${targetChatId}`);
    }
    
    // Enviar mensaje con GIF si está configurado
    if (config.custom_gif_url) {
      console.log(`🎬 🔥 Enviando mensaje con GIF de prueba: ${config.custom_gif_url}`);
      await sendTelegramMessageWithGif(targetChatId, message, config.custom_gif_url);
    } else if (config.custom_gif_file_id) {
      console.log(`🎬 🔥 Enviando mensaje con GIF de Telegram (file_id): ${config.custom_gif_file_id}`);
      await sendTelegramMessageWithGifFileId(targetChatId, message, config.custom_gif_file_id);
    } else {
      // Enviar mensaje normal si no hay GIF configurado
      await sendTelegramMessage(targetChatId, message);
    }
    
    console.log(`🧪 ✅ ¡COMPRA DE PRUEBA ENVIADA EXITOSAMENTE! Chat: ${targetChatId}`);
    
    // Enviar mensaje de confirmación
    await new Promise(resolve => setTimeout(resolve, 2000));
    await sendTelegramMessage(chatId, 
      `✅ <b>Compra de prueba enviada!</b>\n\n` +
      `🧪 Esta fue una simulación para mostrar cómo aparecen las alertas reales.\n\n` +
      `💡 <b>Datos simulados:</b>\n` +
      `• Token: ${mockPurchase.token_name} (${mockPurchase.token_symbol})\n` +
      `• Valor: $${mockPurchase.usd_value.toLocaleString()}\n` +
      `• Cadena: ${mockPurchase.chain}\n\n` +
      `🏆 <b>TOP TOKENS DESTACADOS:</b>\n` +
      `⭐ MANYU - The Only Black Shiba Inu\n` +
      `⭐ Zeus Dog - Meme Of The Millenium\n` +
      `🪙 Wojak - Feel the market emotions\n` +
      `🪙 Bonk - Solana's first dog coin\n` +
      `🪙 Dogwifhat - Dog with a hat on Solana\n\n` +
      `💡 <i>Usa /start para ver todos los TOP TOKENS y añadirlos a tu monitoreo</i>\n\n` +
      `📍 <b>Enviado a:</b> ${targetChatId === chatId ? 'Este chat' : `Grupo ${targetChatId}`}\n\n` +
      `🎯 Las alertas reales aparecerán automáticamente cuando se detecten compras.`
    );
    
  } catch (error) {
    console.error('❌ 🔥 ERROR EN handleTestCommand:', error);
    console.error('❌ 🔥 STACK TRACE:', error.stack);
    
    await sendTelegramMessage(chatId, 
      '❌ <b>Error enviando compra de prueba</b>\n\n' +
      'Por favor intenta de nuevo en unos momentos.'
    );
  }
}

async function handleClearRateCommand(chatId) {
  try {
    const { clearRateLimiting } = await import('./free-apis.js');
    const clearedCount = clearRateLimiting();
    
    await sendTelegramMessage(chatId, 
      `🔄 <b>Rate Limiting Cleared!</b>\n\n` +
      `✅ Cleared ${clearedCount} rate limit entries\n` +
      `🚀 Next monitoring cycle will check all tokens immediately\n\n` +
      `<i>This is useful for debugging and testing.</i>`
    );
  } catch (error) {
    console.error('Error clearing rate limiting:', error);
    await sendTelegramMessage(chatId, '❌ Error clearing rate limiting.');
  }
}

async function handleCheckApiCommand(chatId) {
  try {
    const etherscanKey = process.env.ETHERSCAN_API_KEY;
    const hasRealKey = etherscanKey && etherscanKey !== 'YourApiKeyToken' && etherscanKey !== 'your_etherscan_api_key';
    
    const message = `🔍 <b>API Configuration Check</b>\n\n` +
      `<b>Etherscan API:</b>\n` +
      `• Status: ${hasRealKey ? '✅ Configured' : '❌ Not configured'}\n` +
      `• Key Preview: ${etherscanKey ? etherscanKey.substring(0, 10) + '...' : 'Not set'}\n` +
      `• Length: ${etherscanKey ? etherscanKey.length : 0} characters\n\n` +
      `<b>Environment Variables:</b>\n` +
      `• NODE_ENV: ${process.env.NODE_ENV || 'not set'}\n` +
      `• PORT: ${process.env.PORT || 'not set'}\n\n` +
      `${hasRealKey ? 
        '✅ <i>Ready to fetch real transactions from Etherscan!</i>' : 
        '⚠️ <i>Using mock transactions. Add ETHERSCAN_API_KEY to .env file.</i>'
      }`;
    
    await sendTelegramMessage(chatId, message);
  } catch (error) {
    console.error('Error checking API configuration:', error);
    await sendTelegramMessage(chatId, '❌ Error checking API configuration.');
  }
}