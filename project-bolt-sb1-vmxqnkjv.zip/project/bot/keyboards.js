// Telegram Inline Keyboards for BuyXanBot
// This file contains all the keyboard layouts and button configurations

export const KEYBOARDS = {
  // Main menu keyboard
  MAIN_MENU: {
    inline_keyboard: [
      [
        { text: '🪙 Manage Tokens', callback_data: 'menu_tokens' },
        { text: '⚙️ Settings', callback_data: 'menu_settings' }
      ],
      [
        { text: '🏆 TOP TOKENS', callback_data: 'menu_top_tokens' },
        { text: '📊 View Stats', callback_data: 'menu_stats' },
      ],
      [
        { text: '❓ Help', callback_data: 'menu_help' }
      ]
    ]
  },

  // Token management menu
  TOKEN_MENU: {
    inline_keyboard: [
      [
        { text: '➕ Add Token', callback_data: 'token_add' },
        { text: '📋 List Tokens', callback_data: 'token_list' }
      ],
      [
        { text: '🗑️ Remove Token', callback_data: 'token_remove' },
        { text: '🔍 Token Info', callback_data: 'token_info' }
      ],
      [
        { text: '⬅️ Back to Main', callback_data: 'menu_main' }
      ]
    ]
  },

  // Chain selection keyboard
  CHAIN_SELECTION: {
    inline_keyboard: [
      [
        { text: '🔷 Ethereum (ETH)', callback_data: 'chain_ETH' },
        { text: '🟣 Solana (SOL)', callback_data: 'chain_SOLANA' }
      ],
      [
        { text: '🟡 BNB Chain (BNB)', callback_data: 'chain_BNB' },
        { text: '🔵 Base (BASE)', callback_data: 'chain_BASE' }
      ],
      [
        { text: '❌ Cancel', callback_data: 'menu_tokens' }
      ]
    ]
  },

  // Settings menu
  SETTINGS_MENU: {
    inline_keyboard: [
      [
        { text: '🎬 Set Custom GIF', callback_data: 'settings_gif' },
        { text: '😊 Set Custom Emoji', callback_data: 'settings_emoji' }
      ],
      [
        { text: '🎭 Choose GIF from Telegram', callback_data: 'settings_gif_telegram' },
        { text: '🗑️ Remove Custom GIF', callback_data: 'settings_gif_remove' }
      ],
      [
        { text: '📝 Message Template', callback_data: 'settings_template' },
        { text: '🔧 Show/Hide Fields', callback_data: 'settings_fields' }
      ],
      [
        { text: '🔔 Purchase Filters', callback_data: 'settings_filters' },
        { text: '⏰ Quiet Hours', callback_data: 'settings_quiet_hours' }
      ],
      [
        { text: '💰 Purchase Filter', callback_data: 'purchase_filter_menu' }
      ],
      [
        { text: '⬅️ Back to Main', callback_data: 'menu_main' }
      ]
    ]
  },

  // Confirmation keyboards
  CONFIRM_DELETE: {
    inline_keyboard: [
      [
        { text: '✅ Yes, Delete', callback_data: 'confirm_delete_yes' },
        { text: '❌ Cancel', callback_data: 'confirm_delete_no' }
      ]
    ]
  },

  // Back button only
  BACK_ONLY: {
    inline_keyboard: [
      [
        { text: '⬅️ Back', callback_data: 'menu_main' }
      ]
    ]
  },

  // Cancel button only
  CANCEL_ONLY: {
    inline_keyboard: [
      [
        { text: '❌ Cancel', callback_data: 'menu_main' }
      ]
    ]
  },

  // Success keyboards with navigation options
  TOKEN_SUCCESS: {
    inline_keyboard: [
      [
        { text: '➕ Add Another Token', callback_data: 'token_add' },
        { text: '📋 View All Tokens', callback_data: 'token_list' }
      ],
      [
        { text: '🧪 Test Purchase Alert', callback_data: 'test_purchase' },
        { text: '⚙️ Settings', callback_data: 'menu_settings' }
      ],
      [
        { text: '🚀 START BUY BOT', callback_data: 'start_buy_bot' },
        { text: '🏠 Main Menu', callback_data: 'menu_main' }
      ]
    ]
  },

  SETTINGS_SUCCESS: {
    inline_keyboard: [
      [
        { text: '🎬 Change GIF', callback_data: 'settings_gif' },
        { text: '😊 Change Emoji', callback_data: 'settings_emoji' }
      ],
      [
        { text: '🧪 Test Alert', callback_data: 'test_purchase' },
        { text: '⚙️ More Settings', callback_data: 'menu_settings' }
      ],
      [
        { text: '⬅️ Back to Menu', callback_data: 'menu_main' },
        { text: '🚀 START BUY BOT', callback_data: 'start_buy_bot' }
      ]
    ]
  },

  GIF_SUCCESS: {
    inline_keyboard: [
      [
        { text: '🧪 Test with New GIF', callback_data: 'test_purchase' },
        { text: '🎬 Change GIF Again', callback_data: 'settings_gif' }
      ],
      [
        { text: '😊 Set Emoji', callback_data: 'settings_emoji' },
        { text: '💰 Set Min Amount', callback_data: 'settings_min_amount' }
      ],
      [
        { text: '⬅️ Back to Settings', callback_data: 'menu_settings' },
        { text: '🏠 Main Menu', callback_data: 'menu_main' }
      ]
    ]
  },

  REMOVAL_SUCCESS: {
    inline_keyboard: [
      [
        { text: '🗑️ Remove Another', callback_data: 'token_remove' },
        { text: '📋 View Remaining', callback_data: 'token_list' }
      ],
      [
        { text: '➕ Add New Token', callback_data: 'token_add' },
        { text: '🏠 Main Menu', callback_data: 'menu_main' }
      ]
    ]
  }
};

// Generar keyboard para selección de plantilla
export function generateTemplateSelectionKeyboard() {
  const { MESSAGE_TEMPLATES } = require('./config.js');
  const keyboard = [];
  
  Object.entries(MESSAGE_TEMPLATES).forEach(([key, template]) => {
    keyboard.push([
      { text: template.name, callback_data: `template_select_${key}` }
    ]);
  });
  
  keyboard.push([
    { text: '⬅️ Back to Settings', callback_data: 'menu_settings' }
  ]);
  
  return { inline_keyboard: keyboard };
}

// Generar keyboard para mostrar/ocultar campos
export function generateFieldsConfigKeyboard(currentFields) {
  const { MESSAGE_FIELDS } = require('./config.js');
  const keyboard = [];
  
  Object.entries(MESSAGE_FIELDS).forEach(([key, field]) => {
    const isEnabled = currentFields[key] !== false;
    const emoji = isEnabled ? '✅' : '❌';
    keyboard.push([
      { text: `${emoji} ${field.name}`, callback_data: `field_toggle_${key}` }
    ]);
  });
  
  keyboard.push([
    { text: '🔄 Reset to Default', callback_data: 'fields_reset' },
    { text: '⬅️ Back', callback_data: 'menu_settings' }
  ]);
  
  return { inline_keyboard: keyboard };
}

// Generar keyboard para filtros de compra
export function generateFiltersKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: '💰 Monto Mínimo USD', callback_data: 'filter_min_amount' },
        { text: '🐋 Modo Ballenas', callback_data: 'filter_whale_mode' }
      ],
      [
        { text: '⏰ Horarios Silenciosos', callback_data: 'filter_quiet_hours' },
        { text: '📊 Límite por Hora', callback_data: 'filter_hourly_limit' }
      ],
      [
        { text: '🔄 Reset Filtros', callback_data: 'filters_reset' },
        { text: '⬅️ Back', callback_data: 'menu_settings' }
      ]
    ]
  };
};

// Generate keyboard for minimum amount selection
export function generateMinAmountKeyboard(currentAmount = 0) {
  const amounts = [
    { label: '🆓 All purchases ($0)', value: 0 },
    { label: '💵 Small ($10+)', value: 10 },
    { label: '💰 Medium ($50+)', value: 50 },
    { label: '💎 Large ($100+)', value: 100 },
    { label: '🔥 Big ($500+)', value: 500 },
    { label: '🐋 Whale ($1000+)', value: 1000 },
    { label: '🏆 Mega ($5000+)', value: 5000 },
    { label: '👑 Ultra ($10000+)', value: 10000 }
  ];
  
  const keyboard = [];
  
  // Add amount buttons (2 per row)
  for (let i = 0; i < amounts.length; i += 2) {
    const row = [];
    const amount1 = amounts[i];
    const amount2 = amounts[i + 1];
    
    const emoji1 = currentAmount === amount1.value ? '✅' : '';
    row.push({
      text: `${emoji1} ${amount1.label}`,
      callback_data: `set_min_amount_${amount1.value}`
    });
    
    if (amount2) {
      const emoji2 = currentAmount === amount2.value ? '✅' : '';
      row.push({
        text: `${emoji2} ${amount2.label}`,
        callback_data: `set_min_amount_${amount2.value}`
      });
    }
    
    keyboard.push(row);
  }
  
  // Add custom amount and back buttons
  keyboard.push([
    { text: '🔧 Custom Amount', callback_data: 'set_min_amount_custom' }
  ]);
  
  keyboard.push([
    { text: '⬅️ Back to Settings', callback_data: 'menu_settings' }
  ]);
  
  return { inline_keyboard: keyboard };
}

// Generate simple purchase filter keyboard with 4 predefined amounts
export function generatePurchaseFilterKeyboard(currentAmount = 150) {
  const amounts = [
    { label: '💵 Small Buys ($25+)', value: 25 },
    { label: '💰 Medium Buys ($150+)', value: 150 },
    { label: '🔥 Big Buys ($1500+)', value: 1500 },
    { label: '🐋 Whale Buys ($2500+)', value: 2500 }
  ];
  
  const keyboard = [];
  
  // Add amount buttons (2 per row)
  for (let i = 0; i < amounts.length; i += 2) {
    const row = [];
    const amount1 = amounts[i];
    const amount2 = amounts[i + 1];
    
    const emoji1 = currentAmount === amount1.value ? '✅ ' : '';
    row.push({
      text: `${emoji1}${amount1.label}`,
      callback_data: `purchase_filter_${amount1.value}`
    });
    
    if (amount2) {
      const emoji2 = currentAmount === amount2.value ? '✅ ' : '';
      row.push({
        text: `${emoji2}${amount2.label}`,
        callback_data: `purchase_filter_${amount2.value}`
      });
    }
    
    keyboard.push(row);
  }
  
  return { inline_keyboard: keyboard };
}
// Generate dynamic keyboards
export function generateTokenListKeyboard(tokens) {
  const keyboard = [];
  
  // Group tokens by chain
  const tokensByChain = {};
  tokens.forEach(token => {
    if (!tokensByChain[token.chain]) {
      tokensByChain[token.chain] = [];
    }
    tokensByChain[token.chain].push(token);
  });

  // Add chain sections
  Object.entries(tokensByChain).forEach(([chain, chainTokens]) => {
    // Chain header
    keyboard.push([
      { text: `🔗 ${chain} (${chainTokens.length})`, callback_data: `chain_info_${chain}` }
    ]);
    
    // Tokens in this chain (max 2 per row)
    for (let i = 0; i < chainTokens.length; i += 2) {
      const row = [];
      const token1 = chainTokens[i];
      const token2 = chainTokens[i + 1];
      
      row.push({
        text: `📄 ${token1.contract_address.slice(0, 8)}...`,
        callback_data: `token_details_${token1.id}`
      });
      
      if (token2) {
        row.push({
          text: `📄 ${token2.contract_address.slice(0, 8)}...`,
          callback_data: `token_details_${token2.id}`
        });
      }
      
      keyboard.push(row);
    }
  });

  // Add control buttons
  keyboard.push([
    { text: '➕ Add New Token', callback_data: 'token_add' },
    { text: '🔄 Refresh', callback_data: 'token_list' }
  ]);
  
  keyboard.push([
    { text: '⬅️ Back to Main', callback_data: 'menu_main' }
  ]);

  return { inline_keyboard: keyboard };
}

export function generateTokenDetailsKeyboard(tokenId, chain) {
  return {
    inline_keyboard: [
      [
        { text: '📊 View Chart', callback_data: `token_chart_${tokenId}` },
        { text: '💱 Trade', callback_data: `token_trade_${tokenId}` }
      ],
      [
        { text: '🗑️ Remove Token', callback_data: `token_delete_${tokenId}` },
        { text: '📋 Copy Address', callback_data: `token_copy_${tokenId}` }
      ],
      [
        { text: '⬅️ Back to List', callback_data: 'token_list' }
      ]
    ]
  };
}

export function generateTopTokensKeyboard() {
  const keyboard = [];
  
  // Add header
  keyboard.push([
    { text: '🏆 TOP TOKENS - PROMOCIONES 🏆', callback_data: 'top_tokens_header' }
  ]);
  
  // Add chain sections
  keyboard.push([
    { text: '🔷 Ethereum', callback_data: 'top_tokens_ETH' },
    { text: '🟣 Solana', callback_data: 'top_tokens_SOLANA' }
  ]);
  
  keyboard.push([
    { text: '🟡 BNB Chain', callback_data: 'top_tokens_BNB' },
    { text: '🔵 Base', callback_data: 'top_tokens_BASE' }
  ]);
  
  keyboard.push([
    { text: '⬅️ Back to Main', callback_data: 'menu_main' }
  ]);
  
  return { inline_keyboard: keyboard };
}

export function generateChainTopTokensKeyboard(chain, tokens) {
  const keyboard = [];
  
  // Add tokens (max 2 per row)
  for (let i = 0; i < tokens.length; i += 2) {
    const row = [];
    const token1 = tokens[i];
    const token2 = tokens[i + 1];
    
    const emoji1 = token1.promoted ? '⭐' : '🪙';
    row.push({
      text: `${emoji1} ${token1.symbol}`,
      callback_data: `top_token_details_${chain}_${i}`
    });
    
    if (token2) {
      const emoji2 = token2.promoted ? '⭐' : '🪙';
      row.push({
        text: `${emoji2} ${token2.symbol}`,
        callback_data: `top_token_details_${chain}_${i + 1}`
      });
    }
    
    keyboard.push(row);
  }
  
  // Add control buttons
  keyboard.push([
    { text: '📊 Ver Todos los Chains', callback_data: 'menu_top_tokens' },
    { text: '🏠 Menú Principal', callback_data: 'menu_main' }
  ]);
  
  return { inline_keyboard: keyboard };
}

export function generateTokenDetailKeyboard(chain, tokenIndex) {
  return {
    inline_keyboard: [
      [
        { text: '➕ Monitorizar Token', callback_data: `add_top_token_${chain}_${tokenIndex}` },
        { text: '📊 Ver Gráfico', callback_data: `chart_top_token_${chain}_${tokenIndex}` }
      ],
      [
        { text: '🦄 Tradear Ahora', callback_data: `trade_top_token_${chain}_${tokenIndex}` },
        { text: '🌐 Sitio Web', callback_data: `website_top_token_${chain}_${tokenIndex}` }
      ],
      [
        { text: `⬅️ Volver a ${chain}`, callback_data: `top_tokens_${chain}` },
        { text: '🏠 Menú Principal', callback_data: 'menu_main' }
      ]
    ]
  };
}

// Setup completion keyboards
export const SETUP_INCOMPLETE = {
  inline_keyboard: [
    [
      { text: '➕ Add First Token', callback_data: 'token_add' },
      { text: '🏆 Browse TOP TOKENS', callback_data: 'menu_top_tokens' }
    ],
    [
      { text: '🎬 Set GIF', callback_data: 'settings_gif' },
      { text: '😊 Set Emoji', callback_data: 'settings_emoji' }
    ],
    [
      { text: '🏠 Main Menu', callback_data: 'menu_main' }
    ]
  ]
};

export const SETUP_COMPLETE = {
  inline_keyboard: [
    [
      { text: '🧪 Test Alert', callback_data: 'test_purchase' },
      { text: '➕ Add More Tokens', callback_data: 'token_add' }
    ],
    [
      { text: '⚙️ Bot Settings', callback_data: 'menu_settings' },
      { text: '📊 View Stats', callback_data: 'menu_stats' }
    ],
    [
      { text: '🏠 Main Menu', callback_data: 'menu_main' }
    ]
  ]
};

// User state management for multi-step operations
export const USER_STATES = {
  IDLE: 'idle',
  ADDING_TOKEN_WAITING_CHAIN: 'adding_token_waiting_chain',
  ADDING_TOKEN_WAITING_ADDRESS: 'adding_token_waiting_address',
  SETTING_GIF_WAITING_URL: 'setting_gif_waiting_url',
  SETTING_GIF_WAITING_TELEGRAM: 'setting_gif_waiting_telegram',
  SETTING_EMOJI_WAITING_INPUT: 'setting_emoji_waiting_input',
  REMOVING_TOKEN_WAITING_SELECTION: 'removing_token_waiting_selection'
};

// Store user states in memory (in production, use Redis or database)
export const userStates = new Map();

export function setUserState(chatId, state, data = {}) {
  userStates.set(chatId, { state, data, timestamp: Date.now() });
}

export function getUserState(chatId) {
  return userStates.get(chatId) || { state: USER_STATES.IDLE, data: {}, timestamp: Date.now() };
}

export function clearUserState(chatId) {
  userStates.delete(chatId);
}

// Clean up old states (older than 10 minutes)
setInterval(() => {
  const tenMinutesAgo = Date.now() - 10 * 60 * 1000;
  for (const [chatId, stateData] of userStates.entries()) {
    if (stateData.timestamp < tenMinutesAgo) {
      userStates.delete(chatId);
    }
  }
}, 60000); // Clean every minute