import { getWatchedTokens } from '../database/queries.js';
import { sendTelegramMessage, sendTelegramAnimation } from './telegram.js';
import { formatPurchaseMessage, shouldSendPurchaseAlert, createPurchaseKeyboard } from './formatters.js';
import { 
  getTokenInfoFromDexScreener, 
  getRecentTokenTransactions, 
  detectPurchases,
  getCryptoPrices,
  isRateLimited 
} from './free-apis.js';

export async function monitorAllChains() {
  console.log('🔍 Starting blockchain monitoring...');
  console.log('🔍 🔥 MONITOREO INICIADO - Timestamp:', new Date().toISOString());
  
  try {
    // Get current crypto prices
    const cryptoPrices = await getCryptoPrices();
    console.log('💰 Current prices:', cryptoPrices);
    
    const allTokens = await getWatchedTokens();
    console.log(`🔍 🔥 TOTAL TOKENS EN BASE DE DATOS: ${allTokens.length}`);
    console.log(`🔍 🔥 TOKENS DETALLADOS:`, JSON.stringify(allTokens, null, 2));
    
    const tokensByChat = {};
    
    // Group tokens by chat_id
    allTokens.forEach(token => {
      if (!tokensByChat[token.chat_id]) {
        tokensByChat[token.chat_id] = {};
      }
      if (!tokensByChat[token.chat_id][token.chain]) {
        tokensByChat[token.chat_id][token.chain] = [];
      }
      tokensByChat[token.chat_id][token.chain].push(token.contract_address);
    });
    
    console.log(`🔍 🔥 TOKENS AGRUPADOS POR CHAT:`, JSON.stringify(tokensByChat, null, 2));
    console.log(`🔍 🔥 NÚMERO DE CHATS CON TOKENS: ${Object.keys(tokensByChat).length}`);
    
    // Monitor each chat's tokens
    for (const [chatId, chainTokens] of Object.entries(tokensByChat)) {
      console.log(`🔍 🔥 ===== MONITOREANDO CHAT ${chatId} =====`);
      console.log(`🔍 🔥 Chains disponibles:`, Object.keys(chainTokens));
      
      for (const [chain, contracts] of Object.entries(chainTokens)) {
        console.log(`🔍 🔥 --- CHAIN: ${chain} ---`);
        console.log(`🔍 🔥 Contratos: ${contracts.length}`);
        console.log(`🔍 🔥 Lista de contratos:`, contracts);
        
        const purchases = await getLatestTokenPurchasesFromFreeAPIs(chain, contracts, cryptoPrices);
        
        console.log(`🔍 🔥 COMPRAS DETECTADAS: ${purchases.length} para ${chain} en chat ${chatId}`);
        
        if (purchases.length > 0) {
          console.log(`🔍 🔥 DETALLES DE COMPRAS:`, JSON.stringify(purchases, null, 2));
        }
        
        for (const purchase of purchases) {
          console.log(`🎯 🔥 ===== PROCESANDO COMPRA =====`);
          console.log(`🎯 🔥 Token: ${purchase.token_symbol}`);
          console.log(`🎯 🔥 Valor USD: $${purchase.usd_value}`);
          console.log(`🎯 🔥 Chat destino: ${chatId}`);
          console.log(`🎯 🔥 Timestamp: ${new Date(purchase.timestamp).toISOString()}`);
          
          await processPurchaseAlert(parseInt(chatId), purchase);
          
          console.log(`🎯 🔥 ===== COMPRA PROCESADA =====`);
        }
      }
      console.log(`🔍 🔥 ===== CHAT ${chatId} COMPLETADO =====`);
    }
    
    console.log('✅ 🔥 MONITOREO BLOCKCHAIN COMPLETADO - Timestamp:', new Date().toISOString());
  } catch (error) {
    console.error('❌ 🔥 ERROR EN MONITOREO BLOCKCHAIN:', error);
    console.error('❌ 🔥 STACK TRACE:', error.stack);
  }
}

async function getLatestTokenPurchasesFromFreeAPIs(chain, contractAddresses, cryptoPrices) {
  console.log(`🔍 🔥 ===== CHECKING ${chain} USANDO FREE APIs =====`);
  console.log(`🔍 🔥 Contratos a revisar:`, contractAddresses);
  console.log(`🔍 🔥 Número de contratos: ${contractAddresses.length}`);
  
  const purchases = [];
  
  for (const contractAddress of contractAddresses) {
    console.log(`🔍 🔥 --- Procesando contrato: ${contractAddress} ---`);
    
    // Rate limiting to avoid hitting API limits
    const rateLimitKey = `${chain}-${contractAddress}`;
    const rateLimitKeyAlt = `${contractAddress}-${chain}`; // También limpiar formato alternativo
    if (isRateLimited(rateLimitKey, 15000)) { // 15 segundos entre llamadas
      continue;
    }
    
    try {
      // Get token information from DexScreener
      console.log(`📊 🔥 Obteniendo info del token desde DexScreener...`);
      const tokenInfo = await getTokenInfoFromDexScreener(contractAddress, chain);
      if (!tokenInfo) {
        console.log(`❌ 🔥 NO TOKEN INFO: ${contractAddress} en ${chain}`);
        continue;
      }
      
      console.log(`✅ 🔥 TOKEN INFO ENCONTRADA: ${tokenInfo.token_name} (${tokenInfo.token_symbol})`);
      console.log(`📊 🔥 Precio: $${tokenInfo.price_usd}, Market Cap: $${tokenInfo.market_cap}`);
      
      // Get recent transactions
      console.log(`📋 🔥 Obteniendo transacciones recientes...`);
      const transactions = await getRecentTokenTransactions(contractAddress, chain, 20);
      if (transactions.length === 0) {
        console.log(`📭 🔥 NO HAY TRANSACCIONES RECIENTES: ${contractAddress}`);
        continue;
      }
      
      console.log(`📊 🔥 TRANSACCIONES ENCONTRADAS: ${transactions.length}`);
      
      // Detect purchases from transactions
      console.log(`🔍 🔥 Detectando compras en las transacciones...`);
      const detectedPurchases = detectPurchases(transactions, tokenInfo);
      console.log(`🎯 🔥 COMPRAS DETECTADAS (todas): ${detectedPurchases.length}`);
      
      // Filter for recent purchases (last 10 minutes)
      console.log(`⏰ 🔥 Filtrando compras de los últimos 30 minutos...`);
      const recentPurchases = detectedPurchases.filter(purchase => {
        const purchaseTime = new Date(purchase.timestamp);
        const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);
        const isRecent = purchaseTime > thirtyMinutesAgo;
        console.log(`⏰ 🔥 Compra timestamp: ${purchaseTime.toISOString()}, Es reciente: ${isRecent}`);
        return purchaseTime > thirtyMinutesAgo;
      });
      
      if (recentPurchases.length > 0) {
        console.log(`🎯 🔥 COMPRAS RECIENTES ENCONTRADAS: ${recentPurchases.length} para ${tokenInfo.token_symbol}`);
        purchases.push(...recentPurchases);
      } else {
        console.log(`⏰ 🔥 NO HAY COMPRAS RECIENTES (últimos 30 min) para ${tokenInfo.token_symbol}`);
      }
      
      // Small delay to be respectful to APIs
      await new Promise(resolve => setTimeout(resolve, 1000));
      
    } catch (error) {
      console.error(`❌ 🔥 ERROR procesando ${contractAddress} en ${chain}:`, error.message);
      console.error(`❌ 🔥 Stack trace:`, error.stack);
    }
  }
  
  console.log(`🔍 🔥 ===== RESUMEN ${chain} =====`);
  console.log(`🔍 🔥 Total compras encontradas: ${purchases.length}`);
  return purchases;
}

async function processPurchaseAlert(chatId, purchase) {
  try {
    console.log(`🎯 🔥 PROCESANDO ALERTA DE COMPRA para chat ${chatId}`);
    console.log(`🎯 🔥 Token: ${purchase.token_name} (${purchase.token_symbol})`);
    console.log(`🎯 🔥 Valor USD: $${purchase.usd_value}`);
    
    // Get bot config for this chat
    const { getBotConfig } = await import('../database/queries.js');
    const config = await getBotConfig(chatId);
    
    console.log(`🎯 🔥 Config obtenida:`, JSON.stringify(config, null, 2));
    
    // Check if bot is active - don't send alerts during setup
    if (!config.bot_active) {
      console.log(`🚫 🔥 Bot inactivo para chat ${chatId} - no enviando alerta (modo configuración)`);
      return;
    }
    
    // Aplicar filtros de compra
    if (!shouldSendPurchaseAlert(purchase, config)) {
      console.log(`🚫 🔥 Alerta filtrada para chat ${chatId}`);
      return;
    }
    
    // Format and send purchase message with GIF included
    const message = formatPurchaseMessage(purchase, config);
    console.log(`📝 🔥 Mensaje formateado (longitud: ${message.length})`);
    console.log(`📝 🔥 Mensaje completo:`, message);
    
    // Determinar a qué chat enviar el mensaje
    let targetChatId = config.target_group_id || chatId;
    
    // Si el chat original es un grupo/supergrupo, usar ese como target
    if (chatId.toString().startsWith('-')) {
      targetChatId = chatId;
      console.log(`👥 🔥 Chat es grupo/supergrupo, enviando a: ${targetChatId}`);
    }
    
    console.log(`📤 🔥 Enviando mensaje a chat: ${targetChatId} (original: ${chatId})`);
    
    // Send message with GIF if configured
    await sendPurchaseMessage(targetChatId, message, config, purchase);
    
    console.log(`📢 🔥 ¡ALERTA DE COMPRA ENVIADA EXITOSAMENTE! Chat: ${targetChatId}`);
    
    // Add small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000));
    
  } catch (error) {
    console.error(`❌ 🔥 ERROR procesando alerta de compra para chat ${chatId}:`, error);
    console.error(`❌ 🔥 Stack trace:`, error.stack);
  }
}

async function sendPurchaseMessage(chatId, message, config, purchase) {
  const { sendTelegramMessage, sendTelegramMessageWithGif, sendTelegramMessageWithGifFileId } = await import('./telegram.js');
  
  try {
    // Create keyboard for the purchase message
    const keyboard = createPurchaseKeyboard(purchase.token_address, purchase.chain);
    
    if (config.custom_gif_url) {
      console.log(`🎬 🔥 Enviando mensaje con GIF personalizado: ${config.custom_gif_url}`);
      await sendTelegramMessageWithGif(chatId, message, config.custom_gif_url, "HTML", keyboard);
    } else if (config.custom_gif_file_id) {
      console.log(`🎬 🔥 Enviando mensaje con GIF de Telegram (file_id): ${config.custom_gif_file_id}`);
      await sendTelegramMessageWithGifFileId(chatId, message, config.custom_gif_file_id, "HTML", keyboard);
    } else {
      // Send normal text message if no GIF configured
      await sendTelegramMessage(chatId, message, "HTML", keyboard);
    }
  } catch (error) {
    console.error(`❌ Error enviando mensaje de compra:`, error);
    throw error;
  }
}