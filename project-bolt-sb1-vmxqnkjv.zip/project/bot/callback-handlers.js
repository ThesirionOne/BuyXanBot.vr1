import { getWatchedTokens, addWatchedToken, updateBotConfig, getBotConfig } from '../database/queries.js';
import { formatPurchaseMessage } from './formatters.js';
import { KEYBOARDS, setUserState, getUserState, clearUserState, USER_STATES } from './keyboards.js';
import { sendTelegramMessage } from './telegram.js';

export async function handleCallbackQuery(callbackQuery) {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = callbackQuery.data;
  
  console.log(`📞 🔥 Callback received: ${data} from chat ${chatId}`);
  
  try {
    // Answer callback query first
    const { sendTelegramRequest } = await import('./telegram.js');
    await sendTelegramRequest('answerCallbackQuery', { callback_query_id: callbackQuery.id });
    
    // Route to appropriate handler
    switch (data) {
      case 'menu_tokens':
        await handleTokensMenu(chatId, messageId);
        break;
      case 'menu_settings':
        await handleSettingsMenu(chatId, messageId);
        break;
      case 'menu_top_tokens':
        await handleTopTokensMenu(chatId, messageId);
        break;
      case 'menu_stats':
        await handleStatsMenu(chatId, messageId);
        break;
      case 'menu_help':
        await handleHelpMenu(chatId, messageId);
        break;
      case 'menu_main':
        await handleMainMenu(chatId, messageId);
        break;
      case 'token_add':
        await handleTokenAdd(chatId, messageId);
        break;
      case 'token_list':
        await handleTokenList(chatId, messageId);
        break;
      case 'token_remove':
        await handleTokenRemove(chatId, messageId);
        break;
      case 'settings_gif':
        await handleSettingsGif(chatId, messageId);
        break;
      case 'settings_gif_telegram':
        await handleSettingsGifTelegram(chatId, messageId);
        break;
      case 'settings_gif_remove':
        await handleSettingsGifRemove(chatId, messageId);
        break;
      case 'settings_emoji':
        await handleSettingsEmoji(chatId, messageId);
        break;
      case 'settings_template':
        await handleSettingsTemplate(chatId, messageId);
        break;
      case 'settings_fields':
        await handleSettingsFields(chatId, messageId);
        break;
      case 'test_purchase':
        await handleTestPurchase(chatId, messageId);
        break;
      case 'start_buy_bot':
        await handleStartBuyBot(chatId, messageId);
        break;
      case 'purchase_filter_menu':
        await handlePurchaseFilterMenu(chatId, messageId);
        break;
      default:
        if (data.startsWith('chain_')) {
          await handleChainSelection(chatId, messageId, data);
        } else if (data.startsWith('top_tokens_')) {
          await handleTopTokensChain(chatId, messageId, data);
        } else if (data.startsWith('top_token_details_')) {
          await handleTopTokenDetails(chatId, messageId, data);
        } else if (data.startsWith('add_top_token_')) {
          await handleAddTopToken(chatId, messageId, data);
        } else if (data.startsWith('template_select_')) {
          await handleTemplateSelect(chatId, messageId, data);
        } else if (data.startsWith('field_toggle_')) {
          await handleFieldToggle(chatId, messageId, data);
        } else if (data.startsWith('fields_reset')) {
          await handleFieldsReset(chatId, messageId);
        } else if (data.startsWith('purchase_filter_')) {
          await handlePurchaseFilterSelect(chatId, messageId, data);
        } else {
          console.log(`❓ Unknown callback: ${data}`);
        }
    }
  } catch (error) {
    console.error('❌ Error handling callback query:', error);
  }
}

async function handleMainMenu(chatId, messageId) {
  const config = await getBotConfig(chatId);
  const tokens = await getWatchedTokens(chatId);
  
  const welcomeMessage = `🤖 <b>Welcome to BuyXanBot!</b>

I'm your multi-chain token purchase detection bot! 🚀

<b>🎯 What I do:</b>
• Monitor token purchases in real-time
• Send instant alerts with purchase details
• Support 4 major blockchains
• Customizable notifications

<b>🔗 Supported Networks:</b>
• ETH (Ethereum)
• SOLANA (Solana)
• BNB (BNB Chain)
• BASE (Base)

<b>📊 Current Status:</b>
• Monitoring: <b>${tokens.length}</b> token(s)
• Custom Settings: <b>${config.custom_gif_url ? 'GIF + ' : ''}${config.custom_emoji !== '🟢' ? 'Emoji' : 'Default'}</b>

<i>Use the buttons below to get started:</i>`;

  await editMessage(chatId, messageId, welcomeMessage, KEYBOARDS.MAIN_MENU);
}

async function handleTokensMenu(chatId, messageId) {
  const tokens = await getWatchedTokens(chatId);
  const config = await getBotConfig(chatId);
  
  let message = `🪙 <b>Token Management</b>\n\n`;
  
  if (tokens.length === 0) {
    message += `📝 No tokens configured yet.\n`;
    message += `Add your first token to start receiving buy alerts!\n\n`;
    message += `💡 <b>Quick Start:</b>\n`;
    message += `• Add a token from our TOP TOKENS\n`;
    message += `• Or add your own custom token`;
  } else {
    message += `📊 <b>Active Tokens:</b> ${tokens.length}\n`;
    message += `🤖 <b>Bot Status:</b> ${config?.bot_active ? '🟢 ACTIVE' : '🟡 SETUP MODE'}\n\n`;
    
    message += `<b>Your Tokens:</b>\n`;
    tokens.forEach((token, index) => {
      message += `${index + 1}. 🪙 <b>${token.contract_address.slice(0, 8)}...</b> (${token.chain})\n`;
    });
  }

  await editMessage(chatId, messageId, message, KEYBOARDS.TOKEN_MENU);
}

async function handleTokenAdd(chatId, messageId) {
  const message = `➕ <b>Add New Token</b>\n\n` +
                 `🔗 <b>Choose how to add your token:</b>\n\n` +
                 `🏆 <b>TOP TOKENS</b> - Browse our curated selection\n` +
                 `🆕 <b>CUSTOM TOKEN</b> - Add your own by blockchain\n\n` +
                 `💡 <i>Tip: TOP TOKENS are pre-verified and trending!</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '🏆 TOP TOKENS', callback_data: 'menu_top_tokens' },
        { text: '🆕 CUSTOM TOKEN', callback_data: 'chain_select' }
      ],
      [{ text: '⬅️ Back', callback_data: 'menu_tokens' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleChainSelection(chatId, messageId, data) {
  if (data === 'chain_select') {
    const message = `🔗 <b>Select Blockchain</b>\n\n` +
                   `Choose the blockchain network for your token:\n\n` +
                   `🔷 <b>Ethereum</b> - ERC-20 tokens\n` +
                   `🟣 <b>Solana</b> - SPL tokens\n` +
                   `🟡 <b>BNB Chain</b> - BEP-20 tokens\n` +
                   `🔵 <b>Base</b> - Base network tokens`;

    await editMessage(chatId, messageId, message, KEYBOARDS.CHAIN_SELECTION);
  } else {
    // Handle specific chain selection (chain_ETH, chain_SOLANA, etc.)
    const chain = data.replace('chain_', '');
    
    // Set user state to wait for contract address
    setUserState(chatId, USER_STATES.ADDING_TOKEN_WAITING_ADDRESS, { chain });
    
    const chainNames = {
      'ETH': '🔷 Ethereum',
      'SOLANA': '🟣 Solana',
      'BNB': '🟡 BNB Chain',
      'BASE': '🔵 Base'
    };
    
    const message = `${chainNames[chain]} <b>Selected</b>\n\n` +
                   `📋 <b>Please paste the token contract address:</b>\n\n` +
                   `💡 <i>Example:</i>\n` +
                   `<code>0x6982508145454Ce325dDbE47a25d4ec3d2311933</code>\n\n` +
                   `🔍 <i>The bot will automatically verify the contract</i>`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '❌ Cancel', callback_data: 'token_add' }]
      ]
    };

    await editMessage(chatId, messageId, message, keyboard);
  }
}

async function handleSettingsMenu(chatId, messageId) {
  const config = await getBotConfig(chatId);
  
  const message = `⚙️ <b>Bot Settings</b>\n\n` +
                 `🎬 <b>Custom GIF:</b> ${config.custom_gif_url || config.custom_gif_file_id ? '✅ Set' : '❌ Not set'}\n` +
                 `😊 <b>Custom Emoji:</b> ${config.custom_emoji !== '🟢' ? `${config.custom_emoji} Set` : '❌ Default'}\n\n` +
                 `<b>Customize your purchase alerts:</b>\n` +
                 `• Set a custom GIF for alerts\n` +
                 `• Choose your emoji style\n` +
                 `• Test your configuration`;

  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_MENU);
}

async function handleSettingsGif(chatId, messageId) {
  setUserState(chatId, USER_STATES.SETTING_GIF_WAITING_URL);
  
  const message = `🎬 <b>Set Custom GIF</b>\n\n` +
                 `📎 <b>Send your GIF URL:</b>\n\n` +
                 `💡 <b>Tips:</b>\n` +
                 `• Use animated GIFs for best effect\n` +
                 `• Keep file size under 10MB\n` +
                 `• Square format works best\n\n` +
                 `🎯 <i>This will appear in all buy alerts</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '❌ Cancel', callback_data: 'menu_settings' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleSettingsGifTelegram(chatId, messageId) {
  setUserState(chatId, 'setting_gif_waiting_telegram');
  
  const message = `🎭 <b>Choose GIF from Telegram</b>\n\n` +
                 `📱 <b>Send a GIF from your Telegram:</b>\n\n` +
                 `💡 <b>How to:</b>\n` +
                 `• Type @gif in any chat\n` +
                 `• Search for your desired GIF\n` +
                 `• Send it to this chat\n\n` +
                 `🎯 <i>I'll save it for your alerts</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '❌ Cancel', callback_data: 'menu_settings' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleSettingsGifRemove(chatId, messageId) {
  await updateBotConfig(chatId, { 
    custom_gif_url: null,
    custom_gif_file_id: null 
  });
  
  const message = `🗑️ <b>Custom GIF Removed</b>\n\n` +
                 `✅ Your custom GIF has been removed\n` +
                 `📝 Purchase alerts will now use text only\n\n` +
                 `💡 <i>You can set a new GIF anytime</i>`;

  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_SUCCESS);
}

async function handleSettingsEmoji(chatId, messageId) {
  setUserState(chatId, USER_STATES.SETTING_EMOJI_WAITING_INPUT);
  
  const message = `😊 <b>Set Custom Emoji</b>\n\n` +
                 `🎯 <b>Send your emoji:</b>\n\n` +
                 `💡 <b>Examples:</b>\n` +
                 `🚀 🔥 💎 🐕 ⚡ 🌙\n\n` +
                 `📝 <i>Just type the emoji you want to use</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '❌ Cancel', callback_data: 'menu_settings' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleTestPurchase(chatId, messageId) {
  const tokens = await getWatchedTokens(chatId);
  const config = await getBotConfig(chatId);
  
  if (tokens.length === 0) {
    const message = `⚠️ <b>No Tokens to Test</b>\n\n` +
                   `Add a token first to test purchase alerts!`;
    
    const keyboard = {
      inline_keyboard: [
        [{ text: '➕ Add Token', callback_data: 'token_add' }],
        [{ text: '⬅️ Back', callback_data: 'menu_main' }]
      ]
    };

    await editMessage(chatId, messageId, message, keyboard);
    return;
  }

  // Create test purchase data
  const testPurchase = {
    token_name: 'Test Token',
    token_symbol: 'TEST',
    chain: 'ETH',
    native_amount: 0.25,
    token_amount: 50000000,
    buyer_address: '0x742d35Cc6634C0532925a3b8D4C9db96590c6C87',
    txn_hash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
    token_address: '0x6982508145454Ce325dDbE47a25d4ec3d2311933',
    price_usd: 0.0000125,
    market_cap_usd: 2500000,
    total_supply: 1000000000000,
    usd_value: 875.50,
    timestamp: Date.now()
  };

  // Format and send test message
  const testMessage = formatPurchaseMessage(testPurchase, config);
  
  // Send test alert
  if (config.custom_gif_url) {
    const { sendTelegramMessageWithGif } = await import('./telegram.js');
    await sendTelegramMessageWithGif(chatId, testMessage, config.custom_gif_url);
  } else if (config.custom_gif_file_id) {
    const { sendTelegramMessageWithGifFileId } = await import('./telegram.js');
    await sendTelegramMessageWithGifFileId(chatId, testMessage, config.custom_gif_file_id);
  } else {
    await sendTelegramMessage(chatId, testMessage);
  }

  // Update original message
  const message = `🧪 <b>Test Alert Sent!</b>\n\n` +
                 `✅ Check the test purchase alert above\n\n` +
                 `🎯 <b>What to check:</b>\n` +
                 `• Message formatting\n` +
                 `• Custom GIF (if set)\n` +
                 `• Token emoji\n` +
                 `• Button functionality\n\n` +
                 `💡 <i>Adjust settings if needed</i>`;

  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_SUCCESS);
}

async function handleStartBuyBot(chatId, messageId) {
  const tokens = await getWatchedTokens(chatId);
  
  if (tokens.length === 0) {
    const message = `⚠️ <b>No Tokens Configured</b>\n\n` +
                   `Add at least one token before starting the bot!`;
    
    const keyboard = {
      inline_keyboard: [
        [{ text: '➕ Add Token', callback_data: 'token_add' }],
        [{ text: '⬅️ Back', callback_data: 'menu_main' }]
      ]
    };

    await editMessage(chatId, messageId, message, keyboard);
    return;
  }

  // Activate the bot
  await updateBotConfig(chatId, { bot_active: true });
  
  const message = `🚀 <b>BUY BOT ACTIVATED!</b>\n\n` +
                 `🟢 <b>Status:</b> ACTIVE & MONITORING\n` +
                 `🪙 <b>Tokens:</b> ${tokens.length} configured\n\n` +
                 `⚡ <b>Bot Performance:</b>\n` +
                 `• Real-time blockchain monitoring ✅\n` +
                 `• Multi-chain support active ✅\n` +
                 `• Custom alerts configured ✅\n\n` +
                 `💎 <i>Your community will love the buy alerts!</i>`;

  await editMessage(chatId, messageId, message, KEYBOARDS.SETUP_COMPLETE);
}

async function handleTokenList(chatId, messageId) {
  const tokens = await getWatchedTokens(chatId);
  
  if (tokens.length === 0) {
    const message = `📋 <b>No tokens being monitored</b>\n\n` +
                   `Use the button below to add your first token!`;
    
    const keyboard = {
      inline_keyboard: [
        [{ text: '➕ Add First Token', callback_data: 'token_add' }],
        [{ text: '⬅️ Back', callback_data: 'menu_tokens' }]
      ]
    };

    await editMessage(chatId, messageId, message, keyboard);
    return;
  }

  let message = `📋 <b>Monitored Tokens:</b>\n\n`;
  
  const tokensByChain = {};
  tokens.forEach(token => {
    if (!tokensByChain[token.chain]) {
      tokensByChain[token.chain] = [];
    }
    tokensByChain[token.chain].push(token.contract_address);
  });
  
  Object.entries(tokensByChain).forEach(([chain, contracts]) => {
    message += `🔗 <b>${chain}:</b>\n`;
    contracts.forEach(contract => {
      message += `  • <code>${contract}</code>\n`;
    });
    message += `\n`;
  });
  
  message += `<i>Total: ${tokens.length} token(s) monitored</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '➕ Add More', callback_data: 'token_add' }],
      [{ text: '⬅️ Back', callback_data: 'menu_tokens' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleTopTokensMenu(chatId, messageId) {
  const message = `🏆 <b>TOP TOKENS</b>\n\n` +
                 `🔥 <b>Trending tokens across all chains</b>\n` +
                 `Select a blockchain to see featured tokens:\n\n` +
                 `💎 <i>Pre-verified and actively traded</i>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '🔷 Ethereum', callback_data: 'top_tokens_ETH' },
        { text: '🟣 Solana', callback_data: 'top_tokens_SOLANA' }
      ],
      [
        { text: '🟡 BNB Chain', callback_data: 'top_tokens_BNB' },
        { text: '🔵 Base', callback_data: 'top_tokens_BASE' }
      ],
      [{ text: '⬅️ Back', callback_data: 'menu_main' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleTopTokensChain(chatId, messageId, data) {
  const chain = data.replace('top_tokens_', '');
  
  const topTokens = {
    'ETH': [
      { name: 'MANYU', symbol: 'MANYU', contract: '0x95af4af910c28e8ece4512bfe46f1f33687424ce', promoted: true },
      { name: 'Zeus Dog', symbol: 'ZEUS', contract: '0x0f7dc5d02cc1e1f5ee47854d534d332a1081ccc8', promoted: true },
      { name: 'Wojak', symbol: 'WOJAK', contract: '0x5026F006B85729a8b14553FAE6af249aD16c9aaB', promoted: false }
    ],
    'SOLANA': [
      { name: 'Bonk', symbol: 'BONK', contract: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', promoted: true },
      { name: 'Dogwifhat', symbol: 'WIF', contract: 'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm', promoted: true }
    ],
    'BNB': [
      { name: 'SafeMoon', symbol: 'SAFEMOON', contract: '0x42981d0bfbAf196529376EE702F2a9Eb9092fcB5', promoted: false },
      { name: 'BabyDoge', symbol: 'BABYDOGE', contract: '0xc748673057861a797275CD8A068AbB95A902e8de', promoted: true }
    ],
    'BASE': [
      { name: 'Brett', symbol: 'BRETT', contract: '0x532f27101965dd16442E59d40670FaF5eBB142E4', promoted: true }
    ]
  };

  const tokens = topTokens[chain] || [];
  const chainNames = {
    'ETH': '🔷 Ethereum',
    'SOLANA': '🟣 Solana',
    'BNB': '🟡 BNB Chain',
    'BASE': '🔵 Base'
  };

  let message = `${chainNames[chain]} <b>TOP TOKENS</b>\n\n`;
  message += `🔥 <b>Select a token to add:</b>\n\n`;

  const keyboard = { inline_keyboard: [] };

  tokens.forEach((token, index) => {
    const emoji = token.promoted ? '⭐' : '🪙';
    message += `${emoji} <b>${token.name}</b> (${token.symbol})\n`;
    keyboard.inline_keyboard.push([{
      text: `${emoji} Add ${token.name}`,
      callback_data: `add_top_token_${chain}_${index}`
    }]);
  });

  keyboard.inline_keyboard.push([{ text: '⬅️ Back to TOP TOKENS', callback_data: 'menu_top_tokens' }]);

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleAddTopToken(chatId, messageId, data) {
  const parts = data.split('_');
  const chain = parts[3];
  const tokenIndex = parseInt(parts[4]);
  
  const topTokens = {
    'ETH': [
      { name: 'MANYU', symbol: 'MANYU', contract: '0x95af4af910c28e8ece4512bfe46f1f33687424ce' },
      { name: 'Zeus Dog', symbol: 'ZEUS', contract: '0x0f7dc5d02cc1e1f5ee47854d534d332a1081ccc8' },
      { name: 'Wojak', symbol: 'WOJAK', contract: '0x5026F006B85729a8b14553FAE6af249aD16c9aaB' }
    ],
    'SOLANA': [
      { name: 'Bonk', symbol: 'BONK', contract: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263' },
      { name: 'Dogwifhat', symbol: 'WIF', contract: 'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm' }
    ],
    'BNB': [
      { name: 'SafeMoon', symbol: 'SAFEMOON', contract: '0x42981d0bfbAf196529376EE702F2a9Eb9092fcB5' },
      { name: 'BabyDoge', symbol: 'BABYDOGE', contract: '0xc748673057861a797275CD8A068AbB95A902e8de' }
    ],
    'BASE': [
      { name: 'Brett', symbol: 'BRETT', contract: '0x532f27101965dd16442E59d40670FaF5eBB142E4' }
    ]
  };

  const token = topTokens[chain]?.[tokenIndex];
  if (!token) {
    console.error(`Token not found: ${chain} index ${tokenIndex}`);
    return;
  }

  // Add token to database
  const success = await addWatchedToken(chatId, chain, token.contract);
  
  if (success) {
    const message = `✅ <b>Token Added Successfully!</b>\n\n` +
                   `🪙 <b>${token.name}</b> (${token.symbol})\n` +
                   `🔗 Chain: <b>${chain}</b>\n` +
                   `📄 Contract: <code>${token.contract}</code>\n\n` +
                   `🎯 <b>What's Next?</b>\n` +
                   `• Customize your alerts\n` +
                   `• Test the configuration\n` +
                   `• Start monitoring!`;

    await editMessage(chatId, messageId, message, KEYBOARDS.TOKEN_SUCCESS);
  } else {
    const message = `⚠️ <b>Token Already Added</b>\n\n` +
                   `This token is already being monitored.`;
    
    const keyboard = {
      inline_keyboard: [
        [{ text: '➕ Add Another', callback_data: 'menu_top_tokens' }],
        [{ text: '⬅️ Back', callback_data: 'menu_main' }]
      ]
    };

    await editMessage(chatId, messageId, message, keyboard);
  }
}

async function handleSettingsTemplate(chatId, messageId) {
  const config = await getBotConfig(chatId);
  const currentTemplate = config.message_template || 'default';
  
  const templates = {
    'default': {
      name: '🤖 Clásico',
      description: 'Formato completo con toda la información'
    },
    'minimal': {
      name: '📱 Minimalista', 
      description: 'Solo información esencial, formato compacto'
    },
    'whale': {
      name: '🐋 Ballenas',
      description: 'Enfocado en compras grandes, estilo premium'
    },
    'promo': {
      name: '🚀 Promocional',
      description: 'Diseñado para promocionar tokens, llamativo'
    },
    'technical': {
      name: '📊 Técnico',
      description: 'Datos técnicos detallados, para traders avanzados'
    }
  };
  
  let message = `📝 <b>Message Template</b>\n\n`;
  message += `🎯 <b>Current:</b> ${templates[currentTemplate]?.name || 'Default'}\n\n`;
  message += `<b>Choose your alert style:</b>\n\n`;
  
  Object.entries(templates).forEach(([key, template]) => {
    const emoji = currentTemplate === key ? '✅' : '';
    message += `${emoji} <b>${template.name}</b>\n`;
    message += `<i>${template.description}</i>\n\n`;
  });
  
  const keyboard = { inline_keyboard: [] };
  
  Object.entries(templates).forEach(([key, template]) => {
    const emoji = currentTemplate === key ? '✅ ' : '';
    keyboard.inline_keyboard.push([{
      text: `${emoji}${template.name}`,
      callback_data: `template_select_${key}`
    }]);
  });
  
  keyboard.inline_keyboard.push([
    { text: '⬅️ Back to Settings', callback_data: 'menu_settings' }
  ]);
  
  await editMessage(chatId, messageId, message, keyboard);
}

async function handleTemplateSelect(chatId, messageId, data) {
  const templateKey = data.replace('template_select_', '');
  
  const templates = {
    'default': '🤖 Clásico',
    'minimal': '📱 Minimalista',
    'whale': '🐋 Ballenas', 
    'promo': '🚀 Promocional',
    'technical': '📊 Técnico'
  };
  
  await updateBotConfig(chatId, { message_template: templateKey });
  
  const message = `✅ <b>Template Updated!</b>\n\n` +
                 `📝 <b>New Template:</b> ${templates[templateKey]}\n\n` +
                 `🎯 <b>What changed:</b>\n` +
                 `• Alert message format updated\n` +
                 `• Visual style adjusted\n` +
                 `• Information layout optimized\n\n` +
                 `💡 <i>Test your new template with the button below</i>`;
  
  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_SUCCESS);
}

async function handleSettingsFields(chatId, messageId) {
  const config = await getBotConfig(chatId);
  const currentFields = config.show_fields || {
    token_info: true,
    buyer_info: true,
    transaction_info: true,
    market_data: true,
    quick_links: true,
    branding: true
  };
  
  const fieldNames = {
    token_info: '🪙 Token Information',
    buyer_info: '👤 Buyer Information', 
    transaction_info: '💰 Transaction Details',
    market_data: '📊 Market Data',
    quick_links: '⚡ Quick Links',
    branding: '🤖 Bot Branding'
  };
  
  let message = `🔧 <b>Show/Hide Fields</b>\n\n`;
  message += `<b>Customize what appears in alerts:</b>\n\n`;
  
  Object.entries(fieldNames).forEach(([key, name]) => {
    const status = currentFields[key] !== false ? '✅ Shown' : '❌ Hidden';
    message += `${status} ${name}\n`;
  });
  
  message += `\n💡 <i>Toggle fields on/off with buttons below</i>`;
  
  const keyboard = { inline_keyboard: [] };
  
  Object.entries(fieldNames).forEach(([key, name]) => {
    const isEnabled = currentFields[key] !== false;
    const emoji = isEnabled ? '❌ Hide' : '✅ Show';
    keyboard.inline_keyboard.push([{
      text: `${emoji} ${name}`,
      callback_data: `field_toggle_${key}`
    }]);
  });
  
  keyboard.inline_keyboard.push([
    { text: '🔄 Reset to Default', callback_data: 'fields_reset' },
    { text: '⬅️ Back', callback_data: 'menu_settings' }
  ]);
  
  await editMessage(chatId, messageId, message, keyboard);
}

async function handleFieldToggle(chatId, messageId, data) {
  const fieldKey = data.replace('field_toggle_', '');
  const config = await getBotConfig(chatId);
  const currentFields = config.show_fields || {
    token_info: true,
    buyer_info: true,
    transaction_info: true,
    market_data: true,
    quick_links: true,
    branding: true
  };
  
  // Toggle the field
  currentFields[fieldKey] = !currentFields[fieldKey];
  
  await updateBotConfig(chatId, { show_fields: currentFields });
  
  // Refresh the fields menu
  await handleSettingsFields(chatId, messageId);
}

async function handleFieldsReset(chatId, messageId) {
  const defaultFields = {
    token_info: true,
    buyer_info: true,
    transaction_info: true,
    market_data: true,
    quick_links: true,
    branding: true
  };
  
  await updateBotConfig(chatId, { show_fields: defaultFields });
  
  const message = `🔄 <b>Fields Reset to Default</b>\n\n` +
                 `✅ All fields are now visible\n` +
                 `📝 Alert format restored to standard\n\n` +
                 `💡 <i>You can customize again anytime</i>`;
  
  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_SUCCESS);
}

async function handlePurchaseFilterMenu(chatId, messageId) {
  const config = await getBotConfig(chatId);
  const currentAmount = config.purchase_filters?.min_usd_amount || 150;
  
  const message = `💰 <b>Purchase Filter Settings</b>\n\n` +
                 `🎯 <b>Current Minimum:</b> $${currentAmount.toLocaleString()}\n\n` +
                 `📊 <b>Choose your minimum purchase amount:</b>\n` +
                 `Only purchases above this amount will trigger alerts.\n\n` +
                 `💡 <b>This prevents chat spam from small purchases</b>`;

  const { generatePurchaseFilterKeyboard } = await import('./keyboards.js');
  const keyboard = generatePurchaseFilterKeyboard(currentAmount);
  
  await editMessage(chatId, messageId, message, keyboard);
}

async function handlePurchaseFilterSelect(chatId, messageId, data) {
  const amount = parseInt(data.replace('purchase_filter_', ''));
  
  // Get current config
  const config = await getBotConfig(chatId);
  const updatedFilters = { 
    ...(config.purchase_filters || {}), 
    min_usd_amount: amount 
  };
  
  // Update config
  await updateBotConfig(chatId, { purchase_filters: updatedFilters });
  
  // Create success message and return to main menu
  let message = `✅ <b>Purchase Filter Updated!</b>\n\n`;
  message += `💰 <b>New Minimum:</b> $${amount.toLocaleString()}\n\n`;
  
  if (amount === 25) {
    message += `💵 <b>Small Buys Mode</b>\n`;
    message += `Will show purchases of $25 and above\n`;
    message += `⚠️ <i>May result in frequent notifications</i>`;
  } else if (amount === 150) {
    message += `💰 <b>Medium Buys Mode</b> (Recommended)\n`;
    message += `Will show purchases of $150 and above\n`;
    message += `⚡ <i>Good balance of activity and quality</i>`;
  } else if (amount === 1500) {
    message += `🔥 <b>Big Buys Mode</b>\n`;
    message += `Will show purchases of $1,500 and above\n`;
    message += `💎 <i>Focus on significant transactions</i>`;
  } else if (amount === 2500) {
    message += `🐋 <b>Whale Buys Mode</b>\n`;
    message += `Will show purchases of $2,500 and above\n`;
    message += `🏆 <i>Only the biggest purchases</i>`;
  }
  
  message += `\n\n🎯 <b>Ready to continue setting up your bot!</b>`;
  
  await editMessage(chatId, messageId, message, KEYBOARDS.MAIN_MENU);
}

async function handleStatsMenu(chatId, messageId) {
  const tokens = await getWatchedTokens(chatId);
  const config = await getBotConfig(chatId);
  
  const message = `📊 <b>Bot Statistics</b>\n\n` +
                 `🪙 <b>Monitored Tokens:</b> ${tokens.length}\n` +
                 `🤖 <b>Bot Status:</b> ${config?.bot_active ? '🟢 ACTIVE' : '🟡 SETUP MODE'}\n` +
                 `🎬 <b>Custom GIF:</b> ${config?.custom_gif_url || config?.custom_gif_file_id ? '✅ Set' : '❌ Not set'}\n` +
                 `😊 <b>Custom Emoji:</b> ${config?.custom_emoji !== '🟢' ? '✅ Set' : '❌ Default'}\n\n` +
                 `📈 <b>Performance:</b>\n` +
                 `• Real-time monitoring active\n` +
                 `• Multi-chain support enabled\n` +
                 `• Custom alerts configured`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '⬅️ Back to Main', callback_data: 'menu_main' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleHelpMenu(chatId, messageId) {
  const message = `❓ <b>BuyXanBot Help</b>\n\n` +
                 `<b>🤖 What is BuyXanBot?</b>\n` +
                 `A multi-chain token purchase detection bot that monitors buy transactions and sends instant alerts.\n\n` +
                 `<b>🔗 Supported Networks:</b>\n` +
                 `• ETH (Ethereum)\n` +
                 `• SOLANA (Solana)\n` +
                 `• BNB (BNB Chain)\n` +
                 `• BASE (Base)\n\n` +
                 `<b>📋 Quick Commands:</b>\n` +
                 `• /start - Initialize bot\n` +
                 `• /test - Send test alert\n` +
                 `• /help - Show this help\n\n` +
                 `<b>💡 Need Support?</b>\n` +
                 `Contact: @ThesirionOne`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '⬅️ Back to Main', callback_data: 'menu_main' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

async function handleMinAmountSettings(chatId, messageId) {
  const config = await getBotConfig(chatId);
  const currentAmount = config.purchase_filters?.min_usd_amount || 0;
  
  const message = `💰 <b>Minimum Purchase Amount</b>\n\n` +
                 `🎯 <b>Current Setting:</b> $${currentAmount.toLocaleString()}\n\n` +
                 `📊 <b>Why set a minimum?</b>\n` +
                 `• Avoid chat spam from tiny purchases\n` +
                 `• Focus on meaningful transactions\n` +
                 `• Keep your community engaged\n\n` +
                 `💡 <b>Choose your minimum purchase amount:</b>`;

  const keyboard = generateMinAmountKeyboard(currentAmount);
  await editMessage(chatId, messageId, message, keyboard);
}

async function handleSetMinAmount(chatId, messageId, data) {
  const amount = parseInt(data.replace('set_min_amount_', ''));
  
  // Get current config
  const config = await getBotConfig(chatId);
  const updatedFilters = { 
    ...(config.purchase_filters || {}), 
    min_usd_amount: amount 
  };
  
  // Update config
  await updateBotConfig(chatId, { purchase_filters: updatedFilters });
  
  // Create success message
  let message = `✅ <b>Minimum Amount Updated!</b>\n\n`;
  message += `💰 <b>New Setting:</b> $${amount.toLocaleString()}\n\n`;
  
  if (amount === 0) {
    message += `🆓 <b>All purchases</b> will trigger alerts\n`;
    message += `⚠️ <i>This may result in many notifications</i>`;
  } else {
    message += `🎯 Only purchases of <b>$${amount.toLocaleString()}+</b> will trigger alerts\n`;
    message += `🚫 Purchases under $${amount.toLocaleString()} will be ignored`;
  }
  
  message += `\n\n💡 <i>You can change this anytime in settings</i>`;
  
  await editMessage(chatId, messageId, message, KEYBOARDS.SETTINGS_SUCCESS);
}

async function handleSetMinAmountCustom(chatId, messageId) {
  setUserState(chatId, 'setting_min_amount');
  
  const message = `🔧 <b>Set Custom Minimum Amount</b>\n\n` +
                 `💰 <b>Enter your custom minimum amount in USD:</b>\n\n` +
                 `💡 <b>Examples:</b>\n` +
                 `• <code>25</code> - Only $25+ purchases\n` +
                 `• <code>250</code> - Only $250+ purchases\n` +
                 `• <code>2500</code> - Only $2,500+ purchases\n\n` +
                 `📝 <i>Just type the number (without $ symbol)</i>`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '❌ Cancel', callback_data: 'settings_min_amount' }]
    ]
  };

  await editMessage(chatId, messageId, message, keyboard);
}

// Helper function to edit messages
async function editMessage(chatId, messageId, text, replyMarkup) {
  try {
    const { sendTelegramRequest } = await import('./telegram.js');
    await sendTelegramRequest('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text: text,
      parse_mode: 'HTML',
      reply_markup: replyMarkup
    });
  } catch (error) {
    console.error('❌ Error editing message:', error);
    // Fallback: send new message
    await sendTelegramMessage(chatId, text, 'HTML', replyMarkup);
  }
}