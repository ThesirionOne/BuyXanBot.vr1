/*
  # Create BuyXanBot Database Schema

  1. New Tables
    - `bot_configs`
      - `id` (uuid, primary key)
      - `chat_id` (bigint, unique) - Telegram chat ID
      - `watched_tokens` (jsonb) - Tokens being monitored per chain
      - `custom_gif_url` (text) - Custom GIF URL for alerts
      - `custom_emoji` (text) - Custom emoji for alerts
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `watched_tokens`
      - `id` (uuid, primary key)
      - `chat_id` (bigint) - Telegram chat ID
      - `chain` (text) - Blockchain name (ETH, SOLANA, BNB, BASE)
      - `contract_address` (text) - Token contract address
      - `created_at` (timestamp)
    
    - `purchase_alerts`
      - `id` (uuid, primary key)
      - `chat_id` (bigint) - Telegram chat ID
      - `chain` (text) - Blockchain name
      - `token_address` (text) - Token contract address
      - `buyer_address` (text) - Buyer wallet address
      - `txn_hash` (text) - Transaction hash
      - `native_amount` (decimal) - Amount in native currency
      - `token_amount` (decimal) - Amount of tokens purchased
      - `usd_value` (decimal) - USD value of purchase
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for public access (since this is a bot service)
    
  3. Indexes
    - Add indexes for frequently queried columns
    - Add unique constraints where appropriate
*/

-- Create bot_configs table
CREATE TABLE IF NOT EXISTS bot_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id bigint UNIQUE NOT NULL,
  watched_tokens jsonb DEFAULT '{"ETH": [], "SOLANA": [], "BNB": [], "BASE": []}'::jsonb,
  custom_gif_url text,
  custom_emoji text DEFAULT '🟢',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create watched_tokens table
CREATE TABLE IF NOT EXISTS watched_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id bigint NOT NULL,
  chain text NOT NULL,
  contract_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(chat_id, chain, contract_address)
);

-- Create purchase_alerts table
CREATE TABLE IF NOT EXISTS purchase_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id bigint NOT NULL,
  chain text NOT NULL,
  token_address text NOT NULL,
  buyer_address text NOT NULL,
  txn_hash text NOT NULL,
  native_amount decimal(20, 8) NOT NULL,
  token_amount decimal(30, 8) NOT NULL,
  usd_value decimal(15, 2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE bot_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE watched_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_alerts ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (adjust as needed for your security requirements)
CREATE POLICY "Public access to bot_configs"
  ON bot_configs
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public access to watched_tokens"
  ON watched_tokens
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public access to purchase_alerts"
  ON purchase_alerts
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_bot_configs_chat_id ON bot_configs (chat_id);
CREATE INDEX IF NOT EXISTS idx_watched_tokens_chat_id ON watched_tokens (chat_id);
CREATE INDEX IF NOT EXISTS idx_watched_tokens_chain ON watched_tokens (chain);
CREATE INDEX IF NOT EXISTS idx_purchase_alerts_chat_id ON purchase_alerts (chat_id);
CREATE INDEX IF NOT EXISTS idx_purchase_alerts_created_at ON purchase_alerts (created_at DESC);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for bot_configs updated_at
CREATE TRIGGER update_bot_configs_updated_at
  BEFORE UPDATE ON bot_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();