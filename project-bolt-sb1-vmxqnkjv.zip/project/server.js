import express from 'express';
import cors from 'cors';
import compression from 'compression';
import dotenv from 'dotenv';
import cron from 'node-cron';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

import { initializeTelegramBot } from './bot/telegram.js';
import { monitorAllChains } from './bot/blockchain.js';
import { initializeDatabase } from './database/init.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize in-memory storage
await initializeDatabase();

// Initialize Telegram bot
console.log('🚀 Starting BuyXanBot initialization...');

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.error('❌ TELEGRAM_BOT_TOKEN not found in environment');
  console.error('   Please check your .env file');
} else {
  console.log('✅ TELEGRAM_BOT_TOKEN found');
  console.log('🔍 Token length:', process.env.TELEGRAM_BOT_TOKEN.length);
  console.log('🔍 Token preview:', process.env.TELEGRAM_BOT_TOKEN.substring(0, 15) + '...');
  
  try {
    console.log('🚀 Initializing Telegram bot...');
    await initializeTelegramBot();
    console.log('✅ Telegram bot initialization completed');
  } catch (error) {
    console.error('❌ Failed to initialize Telegram bot:', error.message);
  }
}

// API Routes
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Telegram webhook endpoint
app.post('/api/telegram/webhook', async (req, res) => {
  try {
    console.log('🌐 Webhook endpoint hit - /api/telegram/webhook');
    const { handleTelegramWebhook } = await import('./bot/telegram.js');
    await handleTelegramWebhook(req.body);
    res.status(200).json({ success: true });
  } catch (error) {
    console.error('🌐 Webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin API Routes
app.get('/api/admin/configs', async (req, res) => {
  try {
    const { getBotConfigs } = await import('./database/queries.js');
    const configs = await getBotConfigs();
    res.json(configs);
  } catch (error) {
    console.error('Error fetching configs:', error);
    res.status(500).json({ error: 'Failed to fetch configurations' });
  }
});

app.get('/api/admin/stats', async (req, res) => {
  try {
    const { getStats } = await import('./database/queries.js');
    const stats = await getStats();
    res.json(stats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// Serve admin interface
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Schedule blockchain monitoring (every 10 seconds for testing)
cron.schedule('*/10 * * * * *', async () => {
  console.log('🔍 Running scheduled blockchain monitoring...');
  try {
    await monitorAllChains();
  } catch (error) {
    console.error('❌ Monitoring error:', error.message);
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 BuyXanBot server running on port ${PORT}`);
  console.log(`📊 Admin interface: http://localhost:${PORT}/admin`);
  console.log(`🌐 Main interface: http://localhost:${PORT}`);
  console.log(`🤖 Bot is running in POLLING mode - send /start to your Telegram bot!`);
  console.log(`🔍 Bot token configured: ${!!process.env.TELEGRAM_BOT_TOKEN}`);
});