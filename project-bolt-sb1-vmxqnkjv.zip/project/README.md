#BuyXanBot - Multi-Chain Token Purchase Detection Bot

🤖 **BuyXanBot** is an advanced Telegram bot that detects token purchases on multiple blockchains (Ethereum, Solana, BNB Chain, Base) and sends custom alerts to your Telegram groups.

## 🌟 Key Features

- **Multi-Chain**: Support for Ethereum, Solana, BNB Chain, and Base
- **Free APIs**: Use DexScreener, CoinGecko, and public explorers
- **Custom Alerts**: Customizable GIFs and emojis
- **Real-Time**: Continuous transaction monitoring
- **Web Interface**: Full admin panel
- **Database**: Persistent storage with Supabase

## 🚀 Free APIs Used

### DexScreener API
- **Endpoint**: `https://api.dexscreener.com/latest`
- **Usage**: Token, price, and liquidity information
- **Limits**: No authentication required
- **Documentation**: [DexScreener API](https://docs.dexscreener.com/)

### CoinGecko API
- **Endpoint**: `https://api.coingecko.com/api/v3`
- **Usage**: Major cryptocurrency prices
- **Limits**: 50 calls/minute (free)
- **Documentation**: [CoinGecko API](https://www.coingecko.com/en/api)

### Blockchain Explorers (Free)
- **Etherscan**: Free API with 5 calls/second
- **BSCScan**: Free API with similar limits
- **BaseScan**: Free API for Base Network
- **Solscan**: Public API for Solana

## 📋 Bot Commands

```
/start - Initialize the bot and view commands
/addtoken [STRING] [CONTRACT] - Add token to monitor
/removetoken [STRING] [CONTRACT] - Delete token
/listtokens - View tokens monitored
/setgif [URL] - Set custom GIF
/setemoji [EMOJI] - Set custom emoji
/help - Show help
```

### Usage Examples

```bash
# Add Ethereum Token
/addtoken ETH 0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984

# Add Solana Token
/addtoken SOLANA EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v

# Set custom GIF
/setgif https://media.giphy.com/media/your-gif.gif

# Set custom emoji
/setemoji 💰
```

## 📊 How It Works

### 1. Detecting Purchases

```javascript
// The bot queries DexScreener every 2 minutes
const tokenInfo = await getTokenInfoFromDexScreener(contractAddress, chain);

// Gets recent transactions from the browser
const transactions = await getRecentTokenTransactions(contractAddress, chain);

// Detects purchases based on patterns
const purchases = detectPurchases(transactions, tokenInfo);
```

### 2. Alert Format

Alerts include:
- 💰 Amount spent in native currency and USD
- 🪙 Amount of tokens purchased
- 🔷 Buyer's address (linked)
- 📊 Chart links (DexScreener)
- 🦄 Trading links (Uniswap/PancakeSwap)

## 🎯 Advantages of Free APIs

### ✅ Pros
- **No cost**: Completely free to get started
- **Easy setup**: No complex configuration required
- **Reliable data**: DexScreener and CoinGecko are reliable sources
- **Multiple chains**: Native support for all major chains

### ⚠️ Limitations
- **Rate limits**: Call limits per minute/day
- **Latency**: There may be delays of 1-2 minutes.
- **Accuracy**: Detection based on heuristics, not real-time events.

## 🔄 Future Improvements

### For Greater Accuracy
1. **WebSockets**: Implement real-time connections.
2. **Event Logs**: Analyze contract event logs.
3. **DEX Integration**: Connect directly to DEX APIs.
4. **ML Detection**: Use machine learning for better detection.

### For Scalability
1. **Redis Cache**: Cache token data.
2. **Queue System**: Queue system for processing alerts.
3. **Microservices**: Separate monitoring by chains.
4. **CDN**: Use CDN for static assets.

## 🛠️ Project Structure

```
buyxanbot/
├── bot/
│ ├── config.js # Chains configuration
│ ├── telegram.js # Telegram API
│ ├── commands.js # Bot commands
│ ├── blockchain.js # Blockchain monitoring
│ ├── formatters.js # Message formatting
│ └── free-apis.js # 🆕 Free APIs
├── database/
│ ├── init.js # DB initialization
│ └── queries.js # DB queries
├── supabase/
│ ├── migrations/ # DB migrations DB
│ └── functions/ # Edge functions
├── public/
│ ├── index.html # Home page
│ └── admin.html # Admin panel
├── server.js # Main server
└── app.py # Python implementation
```

## 📄 License

This project is licensed under the MIT License. See `LICENSE` for details.

## 🆘 Support

- **Telegram**: [@buyxanbot](https://t.me/buyxanbot)
- **Issues**: [GitHub Issues](https://github.com/tu-usuario/BuyXanBot.vr1/issues)
---

**Made with ❤️ for the crypto community!**