import { DEFAULT_CONFIG } from '../bot/config.js';

// In-memory storage (persists during server runtime)
let botConfigs = {};
let watchedTokens = [];
let botStats = {
  totalChats: 0,
  totalTokens: 0,
  totalPurchases: 0,
  custom_gif_file_id: null,
  activeChains: ['ETH', 'SOLANA', 'BNB', 'BASE']
};

export async function getBotConfig(chatId) {
  if (!botConfigs[chatId]) {
    botConfigs[chatId] = { ...DEFAULT_CONFIG, chat_id: chatId };
    botStats.totalChats = Object.keys(botConfigs).length;
  }
  return botConfigs[chatId];
  
  // Supabase code removed - using in-memory storage only
}

export async function updateBotConfig(chatId, updates) {
  if (!botConfigs[chatId]) {
    botConfigs[chatId] = { ...DEFAULT_CONFIG, chat_id: chatId };
  }
  botConfigs[chatId] = { ...botConfigs[chatId], ...updates };
  return botConfigs[chatId];
  
  // Supabase code removed - using in-memory storage only
}

export async function addWatchedToken(chatId, chain, contractAddress) {
  const existingToken = watchedTokens.find(t => 
    t.chat_id === chatId && t.chain === chain && t.contract_address === contractAddress
  );
  
  if (existingToken) {
    return false; // Already exists
  }
  
  watchedTokens.push({
    id: Date.now(),
    chat_id: chatId,
    chain,
    contract_address: contractAddress,
    created_at: new Date().toISOString()
  });
  
  botStats.totalTokens = watchedTokens.length;
  botStats.totalChats = Object.keys(botConfigs).length;
  
  return true;
}

export async function removeWatchedToken(chatId, chain, contractAddress) {
  const index = watchedTokens.findIndex(t => 
    t.chat_id === chatId && t.chain === chain && t.contract_address === contractAddress
  );
  
  if (index === -1) {
    return false; // Not found
  }
  
  watchedTokens.splice(index, 1);
  botStats.totalTokens = watchedTokens.length;
  
  return true;
}

export async function getWatchedTokens(chatId = null) {
  return chatId ? watchedTokens.filter(t => t.chat_id === chatId) : watchedTokens;
}

export async function getBotConfigs() {
  return Object.values(botConfigs);
}

export async function getStats() {
  return botStats;
}