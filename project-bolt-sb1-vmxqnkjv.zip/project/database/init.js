// BuyXanBot now works without Supabase!
// All data is stored in memory during server runtime
console.log('📦 Using in-memory storage - no database required!');

export async function initializeDatabase() {
  console.log('✅ In-memory storage initialized');
  console.log('💡 Bot configurations will persist during server runtime');
  console.log('⚠️  Data will be lost when server restarts (this is normal for development)');
}